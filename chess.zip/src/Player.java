import java.util.List;
import java.util.ArrayList;

/**
 * {@summary } Player represents a player in game of chess. It holds statistic
 * data about turns done
 */
public class Player {
	GameInstances GI;
	String color;
	Boolean isOnTurn;
	/**
	 * turns made throughout the game
	 */
	int turnsDone = 0;
	/**
	 * how long did this turn take
	 */
	long thisTimeOnTurn = 0;

	long allTimeSpentOnTurn = 0;
	List<Long> allTurns = new ArrayList<Long>();

	private long startTurn = 0;

	Player opponent;

	/**
	 * Player constructor
	 * 
	 * @param color
	 */
	public Player(String color) {
		if (color.equals("BLACK")) {
			isOnTurn = false;
		} else {
			isOnTurn = true;
		}
		this.color = color;
	}

	/**
	 * {@summary }
	 * starts measuring turn time
	 * this player is now on turn
	 */
	public void startTurn() {
		isOnTurn = true;
		startTurn = System.currentTimeMillis();
	}

	/**
	 * {@summary }
	 * ends the measurement of this turn's time
	 * this player is now not on turn
	 * opponent is on turn
	 */
	public void endTurn() {
		if (!isOnTurn) {
			opponent.endTurn();
		}
		long endTurn = System.currentTimeMillis();
		isOnTurn = false;
		turnsDone++;
		thisTimeOnTurn = endTurn - startTurn;
		allTurns.add(thisTimeOnTurn);
		allTimeSpentOnTurn += thisTimeOnTurn;
		opponent.startTurn();
	}

	// ! WARNING doesn't print all data, isn't very useful
	/**
	 * {@summary } Prints statistics into console
	 */
	public void stats() {
		System.out.println(color + ": \n	played: " + turnsDone + " times");
		System.out.println("	Was on turn for " + allTimeSpentOnTurn / 1000.0 + " seconds.");
		System.out.println(opponent.color + ": \n	played: " + opponent.turnsDone + " times");
		System.out.println("	Was on turn for " + opponent.allTimeSpentOnTurn / 1000.0 + " seconds.");
	}

	// ! WARNING this is actually used for statistics
	/**
	 * {@summary } Player toString - used to get the statistics
	 */
	@Override
	public String toString() {
		String ret = color + ": \n	played: " + turnsDone + " times" +
				"\n	Was on turn for " + allTimeSpentOnTurn / 1000.0 + " seconds.\nAverage time for turn: "
				+ averageTimeOnTurn() + " seconds.";
		return ret;
	}

	/**
	 * {@summary } Finishes the game, noone is on turn after this method is applied,
	 * all mesurements are finished
	 */
	public void endGame() {
		if (!isOnTurn) {
			opponent.endTurn();
		} else {
			endTurn();
		}
		isOnTurn = false;
		opponent.isOnTurn = false;
	}

	/**
	 * 
	 * @param opponent
	 */
	public void setopponent(Player opponent) {
		this.opponent = opponent;
	}

	/**
	 * @param d
	 * @return double
	 */
	private double roundThree(double d) {
		return Math.round(d * 1000) / 1000.0;
	}

	private double averageTimeOnTurn() {
		if (turnsDone <= 0) {
			return 0;
		}
		double d = allTimeSpentOnTurn / turnsDone / 1000.0;
		return roundThree(d);
	}
}

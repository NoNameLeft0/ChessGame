/**
 * {@summary }
 * holds information about the killed piece and its coordinates in a list of
 * pieces
 * 
 * @see Piece
 * @author Vojtech Brabec
 */
public class KilledPieceInfo {

	/** Row position in a 2D array of pieces */
	int Iindex;

	/** Column position in a 2D array of pieces */
	int Jindex;

	/** piece that died */
	Piece killedPiece;

	/** position before death */
	Square prevPosition;

	/**
	 * {@summary } KilledPieceInfo constructor
	 * 
	 * @param killedPiece - {@link Piece}: piece that died
	 * @param Iindex      - int: Row index in 2D array of living pieces
	 * @param Jindex      - int: Collumn index in 2D array of living pieces
	 * 
	 * @see Piece
	 */
	KilledPieceInfo(Piece killedPiece, int Iindex, int Jindex) {
		this.killedPiece = killedPiece;
		prevPosition = killedPiece.getPosition();
		this.Iindex = Iindex;
		this.Jindex = Jindex;
	}
}

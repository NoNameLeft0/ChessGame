import java.util.HashMap;
import java.util.Map;

/**
 * {@summary } Type is used to determine a piece type
 * 
 * @see Piece
 * @author Vojtech Brabec
 */
public enum Type {
	KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN;

	private static final Map<Type, Integer> BY_VALUE = new HashMap<>();

	static {
		Type[] t = { KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN };
		for (int i = 0; i < 6; i++) {
			BY_VALUE.put(t[i], 5 - i);
		}
	}

	public static Integer valueofType(Type t) {
		return BY_VALUE.get(t);
	}
}
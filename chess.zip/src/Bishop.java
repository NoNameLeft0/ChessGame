import java.awt.Color;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;
import java.awt.geom.*;

/**
 * {@summary }Bishop represents a bishop on a chessboard.
 * Bishop is a concrete class of Piece
 * 
 * @see Piece
 * @author Vojtech Brabec
 * 
 */
public class Bishop extends Piece {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Bishop constructor
	 * 
	 * @param position - {@link Square} that this piece is standing on
	 * @param color    - black or white
	 * @see Piece
	 */
	public Bishop(Square position, Color color) {
		super(position, color);
	}

	/** @see Piece */
	@Override
	public List<Square> legalMoves() {
		legalMoves = new ArrayList<Square>();
		int Iindex = -1;
		int Jindex = -1;
		boolean found = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (position.equals(squares[i][j])) {
					Iindex = i;
					Jindex = j;
					found = true;
					break;
				}
			}
			if (found) {
				break;
			}
		}
		if (!found) {
			legalMoves.clear();
			return legalMoves;
		}
		// right down
		for (int i = Iindex + 1, j = Jindex + 1; i < 8 && j < 8; i++, j++) {
			if (squares[i][j].hasPiece()) {
				if (!squares[i][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][j]);
					break;
				}
				break;
			}
			legalMoves.add(squares[i][j]);
		}
		// left down
		for (int i = Iindex + 1, j = Jindex - 1; i < 8 && j >= 0; i++, j--) {
			if (squares[i][j].hasPiece()) {
				if (!squares[i][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][j]);
					break;
				}
				break;
			}
			legalMoves.add(squares[i][j]);
		}
		// left up
		for (int i = Iindex - 1, j = Jindex - 1; i >= 0 && j >= 0; i--, j--) {
			if (squares[i][j].hasPiece()) {
				if (!squares[i][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][j]);
					break;
				}
				break;
			}
			legalMoves.add(squares[i][j]);
		}
		// right up
		for (int i = Iindex - 1, j = Jindex + 1; i >= 0 && j < 8; i--, j++) {
			if (squares[i][j].hasPiece()) {
				if (!squares[i][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][j]);
					break;
				}
				break;
			}
			legalMoves.add(squares[i][j]);
		}

		return legalMoves;
	}

	/** @see Piece */
	@Override
	protected void setType() {
		this.type = Type.BISHOP;
	}

	/** @see Piece */
	@Override
	public Shape createShape() {
		double x = position.getPosition().x + padding * 0.5;
		double y = position.getPosition().y + padding * 0.5;
		double wid = getWidth() - padding;

		// torso
		Path2D tor = new Path2D.Double();
		tor.moveTo(x + 0.2 * wid, y + wid);
		tor.lineTo(x + 0.38 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.62 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.8 * wid, y + wid);
		tor.closePath();
		//

		// head
		Path2D head = new Path2D.Double();
		head.moveTo(x + 0.39 * wid, y + 0.45 * wid);
		head.curveTo(x + 0.3 * wid, y + 0.2 * wid, x + 0.5 * wid, y + wid * 0.1, x + wid * 0.5, y);
		head.curveTo(x + 0.5 * wid, y + 0.1 * wid, x + 0.7 * wid, y + 0.2 * wid, x + 0.61 * wid, y + 0.45 * wid);
		head.closePath();
		//

		double r = wid * 0.15;
		double thisw = wid * 0.7;
		Area shape = new Area(new RoundRectangle2D.Double(x + wid * 0.5 - thisw * 0.5, y + 0.9 * wid, thisw, 0.9 * wid,
				0.2 * wid, 0.2 * wid));
		shape.add(new Area(new Ellipse2D.Double(x + wid * 0.5 - r * 0.5, y, r, r)));
		shape.add(new Area(tor));
		shape.add(new Area(head));
		return shape;
	}

}

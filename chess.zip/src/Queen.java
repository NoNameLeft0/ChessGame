import java.awt.Color;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;
import java.awt.geom.*;

/**
 * {@summary }
 * Queen represents a queen on a chessboard
 * Queen is a concrete class of Piece
 * 
 * @see Piece
 * 
 * @author Vojtech Brabec
 */
public class Queen extends Piece {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Queen constructor
	 * 
	 * @param position
	 * @param color
	 */
	public Queen(Square position, Color color) {
		super(position, color);
	}

	/** @see Piece */
	@Override
	public List<Square> legalMoves() {
		legalMoves = new ArrayList<Square>();
		int Iindex = -1;
		int Jindex = -1;
		boolean found = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (position.equals(squares[i][j])) {
					Iindex = i;
					Jindex = j;
					found = true;
					break;
				}
			}
			if (found) {
				break;
			}
		}
		if (!found) {
			legalMoves.clear();
			return legalMoves;
		}
		/* upwards */
		for (int i = Iindex - 1; i >= 0; i--) {
			if (squares[i][Jindex].hasPiece()) {
				if (!squares[i][Jindex].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][Jindex]);
				}
				break;
			}
			legalMoves.add(squares[i][Jindex]);
		}
		/* downwards */
		for (int i = Iindex + 1; i < 8; i++) {
			if (squares[i][Jindex].hasPiece()) {
				if (!squares[i][Jindex].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][Jindex]);
				}
				break;
			}
			legalMoves.add(squares[i][Jindex]);
		}
		/* to the left */
		for (int j = Jindex - 1; j >= 0; j--) {
			if (squares[Iindex][j].hasPiece()) {
				if (!squares[Iindex][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[Iindex][j]);
				}
				break;
			}
			legalMoves.add(squares[Iindex][j]);
		}
		/* to the right */
		for (int j = Jindex + 1; j < 8; j++) {
			if (squares[Iindex][j].hasPiece()) {
				if (!squares[Iindex][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[Iindex][j]);
				}
				break;
			}
			legalMoves.add(squares[Iindex][j]);
		}

		// right down
		for (int i = Iindex + 1, j = Jindex + 1; i < 8 && j < 8; i++, j++) {
			if (squares[i][j].hasPiece()) {
				if (!squares[i][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][j]);
					break;
				}
				break;
			}
			legalMoves.add(squares[i][j]);
		}
		// left down
		for (int i = Iindex + 1, j = Jindex - 1; i < 8 && j >= 0; i++, j--) {
			if (squares[i][j].hasPiece()) {
				if (!squares[i][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][j]);
					break;
				}
				break;
			}
			legalMoves.add(squares[i][j]);
		}
		// left up
		for (int i = Iindex - 1, j = Jindex - 1; i >= 0 && j >= 0; i--, j--) {
			if (squares[i][j].hasPiece()) {
				if (!squares[i][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][j]);
					break;
				}
				break;
			}
			legalMoves.add(squares[i][j]);
		}
		// right up
		for (int i = Iindex - 1, j = Jindex + 1; i >= 0 && j < 8; i--, j++) {
			if (squares[i][j].hasPiece()) {
				if (!squares[i][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][j]);
					break;
				}
				break;
			}
			legalMoves.add(squares[i][j]);
		}

		return legalMoves;
	}

	/**
	 * @see Piece
	 */
	@Override
	public Shape createShape() {
		int x = position.getPosition().x + padding / 2;
		int y = position.getPosition().y + padding / 2;
		int wid = getWidth() - padding;

		Area shape = new Area();

		Path2D tor = new Path2D.Double();
		tor.moveTo(x + 0.2 * wid, y + wid);
		tor.lineTo(x + 0.38 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.62 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.8 * wid, y + wid);
		tor.closePath();

		// crownBase
		Path2D crownBase = new Path2D.Double();
		crownBase.moveTo(x + 0.39 * wid, y + 0.45 * wid);
		crownBase.lineTo(x + 0.3 * wid, y + 0.3 * wid);
		crownBase.lineTo(x + 0.7 * wid, y + 0.3 * wid);
		crownBase.lineTo(x + 0.61 * wid, y + 0.45 * wid);
		crownBase.closePath();

		Path2D tr = new Path2D.Double();
		tr.moveTo(x + 0.4 * wid, y + 0.3 * wid);
		tr.lineTo(x + 0.5 * wid, y + 0.2 * wid);
		tr.lineTo(x + 0.6 * wid, y + 0.3 * wid);
		tr.closePath();

		// base
		double thisw = wid * 0.7;
		shape.add(new Area(new RoundRectangle2D.Double(x + wid * 0.5 - thisw * 0.5, y + 0.9 * wid, thisw, 0.9 * wid,
				0.2 * wid, 0.2 * wid)));

		shape.add(new Area(tor));
		shape.add(new Area(crownBase));
		double r = 0.15 * wid;

		shape.add(new Area(new Ellipse2D.Double(x + 0.2 * wid, y + wid * 0.1, r, r)));
		shape.add(new Area(new Ellipse2D.Double(x + wid * 0.5 - r * 0.5, y, r, r)));
		shape.add(new Area(new Ellipse2D.Double(x + wid * 0.8 + -r, y + wid * 0.1, r, r)));
		shape.add(new Area(tr));

		return shape;
	}

	/** @see Piece */
	@Override
	protected void setType() {
		this.type = Type.QUEEN;
	}

}

import java.awt.*;

import javax.swing.*;

import java.util.Timer;
import java.util.TimerTask;

/**
 * {@summary } Graphical User Interface - this class communicates the gameplay
 * related information to the user.
 * It sets the scale for pieces and squares therefor updating their positions
 * 
 * @see Piece
 * @see Square
 * @see GameInstances
 * @author Vojtech Brabec
 */
public class GUI extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * width of the inner square
	 */
	int wid;

	/**
	 * height of the inner square
	 */
	int hei;
	/**
	 * top left x coordinate of the inner square
	 */
	int x0;
	/**
	 * top left y coordinate of the inner square
	 */
	int y0;
	/**
	 * a scale by which we scale pieces and fields
	 */
	int scale = wid / 8;
	/**
	 * needed to access selected piece etc
	 */
	GameInstances GI;

	/** piece moved from here */
	Square from;
	/** piece moved to here */
	Square to;

	/** determines if we should refresh gui */
	public boolean drawMoves = false;
	/** determines if we play against pc or player */
	public boolean blackCPU = false;

	/**
	 * GUI constructor
	 * {@summary } Creates a centered square that fills as much space as possible
	 * using {@code squareCenterRec()}.
	 * This rectangle will be the canvas for drawing pieces and the chessboard.
	 * Sets background and repaints;
	 * 
	 * @see Piece
	 * @see Square
	 */
	public GUI() {
		squareCenterRec();
		setBackground(getBackground());
		repaint();
	}

	/**
	 * {@summary }
	 * creates a centered rectangle filling up as much space as possible
	 * Sets x0, y0, wid and hei to this rectangle's dimensions
	 */
	private void squareCenterRec() {
		// * INFO cycle 3 times to stablize scale, if scale is set to wid/4 instead ->
		// 3d
		for (int i = 0; i < 3; i++) {
			scale = hei / 8;
			if (wid == 0 || hei == 0) {
				wid = 480;
				hei = 480;
			} else {
				wid = Math.min(getWidth(), getHeight() + 4 * scale);
				hei = wid - 4 * scale;
			}
			x0 = (getWidth() - wid) / 2;
			y0 = (getHeight() - hei) / 2;
		}
	}

	/**
	 * {@summary }
	 * Calling this method starts/restarts the game. A new instance of GameInstances
	 * is created. Than we use method {@code setEverything()} from GameInstances to
	 * prepare the basic chess game.
	 * A new timer is added that refreshes whenever GameInstances allows to.
	 */
	public void start() {
		this.GI = new GameInstances();
		GI.setEverything(this);
		addMouseListener(GI.dragAdapter);
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {

			@Override
			public void run() {
				if (!GI.gameEnds) {
					if (drawMoves) {
						repaint();
					}
				} else {
					removeMouseListener(GI.dragAdapter);
					Main.endScreen(GI.gui);
					timer.cancel();
				}
			}

		}, 0, 16); // 16 because 60 hz monitors have a delay of 16,66... ms

		// * INFO refreshes every second just to be safe */
		timer.schedule(new TimerTask() {

			@Override
			public void run() {
				if (!GI.gameEnds) {
					repaint();
				} else {
					timer.cancel();
				}
			}

		}, 0, 1000);

		repaint();
	}

	/**
	 * {@summary } Draws the cemetary squares and the dead Figures.
	 * 
	 * @param g - Graphics
	 */
	public void drawCemetary(Graphics g) {
		if (GI == null) {
			return;
		}
		int x;
		int y;
		int cemetLen = GI.cemetarySlots.length;
		for (int i = 0; i < cemetLen; i++) {
			if (i < cemetLen / 2) {
				x = x0 + scale / 2;
				y = y0 + i * scale + scale / 2;
			} else {
				x = x0 + wid - 3 * scale / 2;
				y = y0 + (i - cemetLen / 2) * scale + scale / 2;
			}
			GI.cemetarySlots[i].setScale(scale);
			GI.cemetarySlots[i].setPosition(new Point(x, y));
			GI.cemetarySlots[i].setRectangle();
			;
			GI.cemetarySlots[i].paint(g);
		}
		for (int i = 0; i < GI.cemetary.size(); i++) {
			Piece p = GI.cemetary.get(i).killedPiece;
			p.setPosition(p.getPosition());
			p.getPosition().setPiece(p);
			p.paint(g);
		}
	}

	/**
	 * {@summary }
	 * Renders chessBoard.
	 * 
	 * @param n - Graphics
	 */
	public void drawBackground(Graphics n) {
		if (GI == null) {
			return;
		}

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				GI.getSquares()[i][j].setScale(scale);
				GI.getSquares()[i][j].setPosition(new Point(2 * scale + j * scale, i * scale));
				GI.getSquares()[i][j].setRectangle();
				;
				GI.getSquares()[i][j].paint(n);
			}
		}
	}

	/**
	 * {@summary }
	 * Renders living pieces.
	 * 
	 * @param n - Graphics
	 */
	public void drawPieces(Graphics n) {

		if (GI == null) {
			return;
		}
		Piece piece;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				if (GI.getPiece(i, j) != null) {
					piece = GI.getPiece(i, j);
					piece.setBounds(piece.getPosition().getRectangle());
					;
					GI.getPiece(i, j).paint(n);
				}
			}
		}

	}

	/**
	 * {@summary }
	 * Visualisation of possible moves by the selected piece
	 * 
	 * @param g - Graphics
	 */
	public void drawLegalMoves(Graphics g) {
		int x;
		int y;
		wid = scale;
		int r = wid / 4;
		g.setColor(Main.background);
		for (int i = 0; i < GI.getSelectedPiece().legalMoves.size(); i++) {
			x = GI.getSelectedPiece().legalMoves.get(i).getPosition().x;
			y = GI.getSelectedPiece().legalMoves.get(i).getPosition().y;
			g.fillOval(x0 + x + wid / 2 - r / 2, y0 + y + wid / 2 - r / 2, r, r);
		}
	}

	public void highlight(Graphics g) {
		if (GI == null) {
			return;
		}
		from = GI.getPreviousSquare();
		to = GI.getSelectedSquare();
		if (from == null || to == null) {
			return;
		}

		Rectangle from = this.from.getRectangle();
		Rectangle to = this.to.getRectangle();
		g.setColor(Main.highlightColor);
		g.fillRect(from.x + x0, from.y + y0, from.width, from.height);
		g.fillRect(to.x + x0, to.y + y0, to.width, to.height);

	}

	/**
	 * {@summary }
	 * Selected piece will follow mouseCursor untill released
	 * 
	 * @param g - Graphics2D
	 */
	public void updateSelectedPiece(Graphics2D g) {
		try {
			Point cursor = new Point(getMousePosition().x - scale / 2 - x0, getMousePosition().y - y0 - scale / 2);
			GI.getSelectedPiece().setPosition(new Square(cursor, scale, null));
		} catch (NullPointerException e) {
			return;
		}
	}

	/**
	 * @param g - Graphics
	 */
	@Override
	public void paint(Graphics g) {
		g.setColor(getBackground());
		g.fillRect(0, 0, 10000, 10000);
		/* preskalovani graphics na ctverec */

		squareCenterRec();
		Graphics f = g.create(x0, y0, wid, hei);
		Graphics2D n = (Graphics2D) f;
		// n.clearRect(0, 0, wid, hei);
		/* */

		// sachovnice
		drawBackground(n);
		drawCemetary(g);

		highlight(g);

		// pieces
		drawPieces(n);

		// legal moves
		if (drawMoves) {
			drawLegalMoves(g);
			updateSelectedPiece(n);
		}

	}

}
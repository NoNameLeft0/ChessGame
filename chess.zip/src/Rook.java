import java.awt.Color;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;
import java.awt.geom.*;

/**
 * {@summary }Rook is a representation of a rook piece on a chessboard.
 * Rook is a concrete class of Piece.
 * A rook has additionally a King attribute for easier manipulation
 * 
 * @see Piece
 * @author Vojtech Brabec
 */
public class Rook extends Piece {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	King king;

	public Rook(Square position, Color color) {
		super(position, color);
	}

	/**
	 * @return List<Square>
	 */
	@Override
	public List<Square> legalMoves() {
		legalMoves = new ArrayList<Square>();
		int Iindex = -1;
		int Jindex = -1;
		boolean found = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (position.equals(squares[i][j])) {
					Iindex = i;
					Jindex = j;
					found = true;
					break;
				}
			}
			if (found) {
				break;
			}
		}
		if (!found) {
			legalMoves.clear();
			return legalMoves;
		}
		/* upwards */
		for (int i = Iindex - 1; i >= 0; i--) {
			if (squares[i][Jindex].hasPiece()) {
				if (!squares[i][Jindex].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][Jindex]);
				}
				break;
			}
			legalMoves.add(squares[i][Jindex]);
		}
		/* downwards */
		for (int i = Iindex + 1; i < 8; i++) {
			if (squares[i][Jindex].hasPiece()) {
				if (!squares[i][Jindex].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[i][Jindex]);
				}
				break;
			}
			legalMoves.add(squares[i][Jindex]);
		}
		/* to the left */
		for (int j = Jindex - 1; j >= 0; j--) {
			if (squares[Iindex][j].hasPiece()) {
				if (!squares[Iindex][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[Iindex][j]);
				}
				break;
			}
			legalMoves.add(squares[Iindex][j]);
		}
		/* to the right */
		for (int j = Jindex + 1; j < 8; j++) {
			if (squares[Iindex][j].hasPiece()) {
				if (!squares[Iindex][j].getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(squares[Iindex][j]);
				}
				break;
			}
			legalMoves.add(squares[Iindex][j]);
		}

		return legalMoves;
	}

	@Override
	protected void setType() {
		this.type = Type.ROOK;
	}

	@Override
	public Shape createShape() {
int x = position.getPosition().x + padding / 2;
		int y = position.getPosition().y + padding / 2;
		int wid = getWidth() - padding;

		Area shape = new Area();

		Path2D tor = new Path2D.Double();
		tor.moveTo(x + 0.2 * wid, y + wid);
		tor.lineTo(x + 0.38 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.62 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.8 * wid, y + wid);
		tor.closePath();

		double thisw = wid * 0.7;
		shape.add(new Area(new RoundRectangle2D.Double(x + wid * 0.5 - thisw * 0.5, y + 0.9 * wid, thisw, 0.9 * wid,
				0.2 * wid, 0.2 * wid)));
		shape.add(new Area(tor));
		thisw = 0.5 * wid;
		double thish = 0.2 * wid;
		double squareWid = 0.16 * wid;
		shape.add(new Area(
				new Rectangle2D.Double(x + 0.5 * wid - 0.5 * thisw, y + 0.05 * wid + thish, thisw, thish)));

		shape.add(new Area(new Rectangle2D.Double(x + 0.2 * wid, y + squareWid, squareWid, squareWid)));
		shape.add(
				new Area(new Rectangle2D.Double(x + 0.5 * wid - 0.5 * squareWid, y + squareWid, squareWid, squareWid)));
		shape.add(new Area(
				new Rectangle2D.Double(x + 0.8 * wid - squareWid, y + squareWid, squareWid, squareWid)));
		return shape;

	}

	/**
	 * so that rooks can see king
	 * 
	 * @param king
	 */
	public void setKing(King king) {
		this.king = king;
	}

}

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class CPU1 {
	Random random = new Random();

	GameInstances GI;

	Piece pieces[][];
	Piece queen;

	Player white;
	Player black;

	Piece killable;
	Piece killer;
	Square from;
	Square to;

	int killingValue = 0;
	int savingValue = 0;

	// List<Piece> wKillers = new ArrayList<>();
	List<Piece> saveables = new ArrayList<>();

	Piece wKiller;
	Piece saveable;

	List<Piece> killables = new ArrayList<>();
	List<Piece> killers = new ArrayList<>();

	public CPU1(GameInstances GI) {
		System.out.println("init");
		this.GI = GI;
		pieces = GI.getPieces();
		white = GI.white;
		black = GI.black;
		queen = GI.getPiece(0, 3);
	}

	public boolean play() {
		killables.clear();
		killers.clear();
		savingValue = -100;
		killingValue = -100;
		saveable = null;
		killer = null;
		from = null;
		to = null;

		defend();
		attack();
		if (killer != null && saveable != null) {
			if (killable == wKiller) {
				from = killer.getPosition();
				to = wKiller.getPosition();
				GI.movePiece(killer, from, to);

			} else if (killingValue >= savingValue) {
				from = killer.getPosition();
				to = killable.getPosition();
				GI.movePiece(killer, from, to);

			} else {
				saveSaveable();
			}
		} else if (killer != null) {
			from = killer.getPosition();
			to = killable.getPosition();
			GI.movePiece(killer, from, to);
		} else if (saveable != null) {
			saveSaveable();
		} else {
			smarterRandomCPU();
		}
		System.out.println("Saveable " + saveable + " value: " + savingValue);
		System.out.println("Killable " + killable + " value: " + killingValue);

		endTurn();
		if (GI.bKing.inCheck()) {
			GI.undo();
			randomCPU(0);
			endTurn();
			;
		}
		return true;

		// if (killingValue >= savingValue) {
		// if (killer == null) {
		// randomCPU(0);
		// endTurn();
		// return true;
		// }
		// if (killable.equals(wKiller)) {
		// GI.movePiece(killer, killer.getPosition(), wKiller.getPosition());
		// endTurn();
		// return true;
		// }
		// from = killer.getPosition();
		// to = killable.getPosition();
		// GI.movePiece(killer, from, to);
		// endTurn();
		// } else {
		// saveSaveable();
		// endTurn();
		// }
		// return true;
	}

	public void defend() {
		List<Integer> values = new ArrayList<>();
		List<Piece> wKillers = new ArrayList<>();
		for (int i = 0; i < 8; i++) {
			if (pieces[0][i] == null) {
				continue;
			}
			if (pieces[0][i].canBeSaved()) {
				saveables.add(pieces[0][i]);
				wKillers.add(pieces[0][i].canBeKilledBy().get(0));
				values.add(pieces[0][i].getValue() - wKillers.get(wKillers.size() - 1).getValue());
			}
		}

		if (values.size() == 0) {
			savingValue = -100;
			return;
		}

		int index = values.indexOf(Collections.max(values));
		saveable = saveables.get(index);
		wKiller = wKillers.get(index);
		savingValue = saveable.getValue() - wKiller.getValue();
	}

	public void attack() {
		findKillables();
		findBestKillers();
		findBestValuePlay();
	}

	private void saveSaveable() {
		System.out.println("\n defended");
		Piece kp = null;
		Square from = null;
		Square to = null;
		if (saveable == null) {
			return;
		}
		for (int i = 0; i < saveable.legalMoves.size(); i++) {
			from = saveable.getPosition();
			to = saveable.legalMoves.get(i);
			kp = GI.movePiece(saveable, from, to);

			if (!saveable.canBeKilled()) {
				break;
			} else {
				GI.reverseThisMove(new Move(white, black, saveable, kp, from, to));
			}
		}
		this.from = from;
		this.to = to;
		killable = kp;
		killer = saveable;
		// GI.refreshLegalMoves();
		// Piece oldSaveable = saveable;
		// this.to = to;
		// this.from = from;
		// this.killable = kp;
		// killer = saveable;
		// defend();
		// if (oldSaveable.getValue() < saveable.getValue()) {
		// GI.reverseThisMove(new Move(white, black, saveable, kp, from, to));
		// saveable = null;
		// savingValue = -100;
		// attack();
		// }
	}

	/**
	 * {@summary } finds the best tradeof - lowest value killer, highest value kill
	 */
	public void findBestValuePlay() {
		System.out.println();
		System.out.println("finding best value");
		if (killers.size() == 0 || killables.size() == 0) {
			killer = null;
			killable = null;
			killingValue = -100;
			return;
		}

		List<Integer> results = new ArrayList<>();
		for (int i = 0; i < killables.size(); i++) {
			int killableValue = Type.valueofType(killables.get(i).getType());
			int killerValue = Type.valueofType(killers.get(i).getType());
			results.add(killableValue - killerValue);
		}
		int bestValue = Collections.max(results);
		int get = results.indexOf(bestValue);

		Piece pkiller = killers.get(get);
		Piece pkillable = killables.get(get);

		Square from = pkiller.getPosition();
		Square to = pkillable.getPosition();

		GI.movePiece(pkiller, pkiller.getPosition(), pkillable.getPosition());
		GI.refreshLegalMoves();

		boolean iskKillable = pkiller.canBeKilled();

		// TODO can be upgraded lots
		if (iskKillable) {
			int pkValue = Type.valueofType(pkiller.getType());
			int pkAbValue = Type.valueofType(pkillable.getType());
			if (pkValue > pkAbValue) {
				killers.remove(pkiller);
				killables.remove(pkillable);
				GI.reverseThisMove(new Move(white, black, pkiller, pkillable, from, to));
				findBestValuePlay();
				return;
			} else {
				killer = pkiller;
				killable = pkillable;
				killingValue = pkAbValue - pkValue;
			}
		} else {
			killer = pkiller;
			killable = pkillable;
			killingValue = Type.valueofType(killable.getType()) - Type.valueofType(killer.getType());
		}

		GI.reverseThisMove(new Move(white, black, pkiller, pkillable, from, to));
	}

	/** {@summary }finds lowest value killers */
	public void findBestKillers() {
		// * INFO for each killable there are more potential killers, find the lowest
		// value one
		for (int i = 0; i < killables.size(); i++) {
			List<Piece> potentialKillers = killables.get(i).canBeKilledBy();
			List<Integer> killerValues = new ArrayList<>();
			// * INFO for each potential killer, load it's value to values
			for (int j = 0; j < potentialKillers.size(); j++) {
				killerValues.add(Type.valueofType(potentialKillers.get(j).getType()));
			}
			// * INFO find the lowest value in killerValues
			int result = Collections.min(killerValues);
			for (int j = 0; j < killerValues.size(); j++) {
				if (result == killerValues.get(j)) {
					killers.add(potentialKillers.get(j));
					break;
				}
			}
		}
	}

	/** finds all killable pieces */
	public void findKillables() {
		for (int i = 2; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				if (pieces[i][j] == null) {
					continue;
				}

				if (pieces[i][j].canBeKilled()) {
					killables.add(pieces[i][j]);
				}
			}
		}
	}

	private boolean smarterRandomCPU() {
		int calling = 0;
		if (!GI.bKing.inCheck()) {
			randomCPU(calling++);
			while (killer.canBeKilled()) {
				GI.reverseThisMove(new Move(white, black, killer, saveable, from, to));
				randomCPU(calling++);
			}
		} else {
			randomCPU(calling++);
		}
		return true;
	}

	/**
	 * {@summary }
	 * blackCPU is a recursive method that calls itself when black king is at the
	 * end of PC's turn in check.
	 * Follows the same rules as player.
	 * Randomly chooses a black piece and moves with it to a randomly chosen legal
	 * position for this piece.
	 *
	 * @param calling - int: the ammount of recursive calls to prevent stack
	 *                overflow in pat situations
	 * @return true - after the last recursion is performed will always return
	 *         true
	 */
	private boolean randomCPU(int calling) {
		calling++;
		// setup
		Square previousSquare = null;
		Piece selectedPiece = null;
		Square selectedSquare = null;
		;
		// select piece that has at least one legal move randomly
		long timeS = System.currentTimeMillis();
		while (selectedPiece == null || selectedPiece.legalMoves.size() <= 0) {
			selectedPiece = pieces[random.nextInt(0, 2)][random.nextInt(0, 8)];
			if (System.currentTimeMillis() - timeS > 50 || calling > 1000) {
				// white.endGame();
				GI.gameEnds = true;
				return false;
			}
		}
		// prepare for movement
		previousSquare = selectedPiece.getPosition();
		selectedPiece.legalMoves();
		try {
			selectedSquare = selectedPiece.legalMoves.get(random.nextInt(0,
					selectedPiece.legalMoves.size()));
		} catch (IllegalArgumentException exception) {
			System.out.println("illegal argument exception - black cpu - random move " +
					selectedPiece);
			randomCPU(calling);
		}
		if (GI.castle(selectedPiece, selectedSquare)) {
			return true;
		}
		;
		Piece killedPiece = GI.movePiece(selectedPiece, previousSquare,
				selectedSquare);

		// is king in check? recursion
		GI.refreshLegalMoves();
		if (GI.bKing.inCheck()) {
			GI.reverseThisMove(new Move(white, black, selectedPiece, killedPiece, previousSquare, selectedSquare));
			return randomCPU(calling);
		}

		this.from = previousSquare;
		this.to = selectedSquare;
		this.killer = selectedPiece;
		this.saveable = killedPiece;
		System.out.println("did random cpu " + calling);
		return true;
	}

	private void endTurn() {
		GI.replaceOrAddMove(new Move(white, black, killer, killable, from, to));
		killer.movesDone++;
		black.endTurn();
		// try {
		// } catch (NullPointerException e) {
		// black.endTurn();
		// System.out.println("controlled exception - CPU.endTurn");
		// }
	}
}

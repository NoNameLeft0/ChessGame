import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * {@summary } Window class is used for creating a JFrame or adding buttons with
 * previously created listeners.
 * Includes precreated buttons, mouse listeners, templates for a JFrame window.
 * It is iexpected to have only one instance of this class in a program.
 * 
 * @author Vojtech Brabec
 */
public class Window {
	Color background;
	JButton exit = new JButton("Exit");
	JButton startGame = new JButton("Play");
	JButton restart = new JButton("Restart");
	JButton undo = new JButton("<--");
	JButton redo = new JButton("-->");
	JButton stats = new JButton("Stats");
	JButton fullScreen = new JButton("FullScreen");
	JButton vs = new JButton("Play against PC");

	JPanel toolbar = new JPanel();

	MouseListener LVS = new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			if (Main.gui.GI != null && Main.gui.GI.black.isOnTurn) {
				Main.gui.GI.cpu.play();
			}
			if (Main.gui.blackCPU) {
				Main.gui.blackCPU = false;
				vs.setText("Play against PC");
			} else {
				Main.gui.blackCPU = true;
				vs.setText("Play against Player");
			}
		};
	};

	MouseListener LFullScreen = new MouseAdapter() {

		boolean fs = false;
		Rectangle prevSiz;

		@Override
		public void mouseClicked(MouseEvent e) {
			if (!fs) {
				prevSiz = Main.frame.getBounds();
				Main.frame.dispose();
				Main.frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
				Main.frame.setUndecorated(true);
				Main.frame.setVisible(true);
				fs = true;
			} else {
				Main.frame.dispose();
				Main.frame.setBounds(prevSiz);
				Main.frame.setExtendedState(JFrame.NORMAL);
				Main.frame.setUndecorated(false);
				Main.frame.setVisible(true);
				fs = false;
			}
		}
	};

	MouseListener LStats = new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			if (Main.gui.GI == null) {
				System.out.println("oof");
				return;
			}
			Main.stats();
		};
	};

	MouseListener LRedo = new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			Main.gui.GI.redo();
			Main.gui.repaint();
			System.out.println("redo: " + (Main.gui.GI.getMoveNumber() - 1));
		};
	};

	MouseListener LUndo = new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			Main.gui.GI.undo();
			Main.gui.repaint();
			System.out.println("undo: " + Main.gui.GI.getMoveNumber());
		}

	};

	MouseListener LStartOrRestart = new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
			Main.gui.start();
		};
	};

	MouseListener LExit = new MouseAdapter() {

		public void mouseClicked(MouseEvent e) {
			System.exit(0);
		}

	};

	/**
	 * Window constructor
	 * 
	 * @param background
	 */
	public Window(Color background) {
		this.background = background;
		toolbar.setBackground(background);
		exit.addMouseListener(LExit);
		startGame.addMouseListener(LStartOrRestart);
		restart.addMouseListener(LStartOrRestart);
		undo.addMouseListener(LUndo);
		redo.addMouseListener(LRedo);
		stats.addMouseListener(LStats);
		vs.addMouseListener(LVS);
		fullScreen.addMouseListener(LFullScreen);
	}

	/**
	 * {@summary create a new JFrame, customize it from a call place}
	 * 
	 * @param title
	 * @return new JFrame
	 */
	public JFrame customFrame(String title) {

		return new JFrame(title);
	}
}
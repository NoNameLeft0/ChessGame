import javax.swing.*;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * {@summary } Main class - containts main method.
 * The main game window (frame) is created here.
 * Has methods for showing statistics and a Game Over windows
 * 
 * @see GUI
 * @see GameInstances
 * @see Window
 * @author Vojtech Brabec
 */
public class Main {
	/** The maing game window width */
	final static int wid = 800;
	/** The main window height */
	final static int hei = 600;

	/** Main game window */
	final static JFrame frame = new JFrame();

	/** color for highlighting moves */
	final static Color highlightColor = new Color(170, 100, 80, 150);
	/** background color */
	final static Color background = new Color(170, 100, 80);

	/**
	 * GUI for user interface
	 */
	static GUI gui;
	/** Window instance for creating windows */
	static Window window;

	/**
	 * {@summary } creates the main game window called frame, adds buttons, formats
	 * everything nicely
	 * 
	 * @param args - empty
	 */
	public static void main(String[] args) {
		frame.setTitle("Chess Game");

		gui = new GUI();
		gui.setBackground(background);

		window = new Window(background);

		JPanel toolbar = new JPanel();

		toolbar.add(window.vs, BorderLayout.AFTER_LAST_LINE);
		toolbar.add(window.fullScreen, BorderLayout.AFTER_LAST_LINE);
		toolbar.add(window.startGame, BorderLayout.AFTER_LAST_LINE);
		toolbar.add(window.undo, BorderLayout.AFTER_LAST_LINE);
		toolbar.add(window.redo, BorderLayout.AFTER_LINE_ENDS);
		toolbar.add(window.stats, BorderLayout.AFTER_LAST_LINE);
		toolbar.add(window.exit, BorderLayout.AFTER_LAST_LINE);

		frame.add(toolbar, BorderLayout.PAGE_START);
		frame.add(gui);

		frame.setBackground(background);
		toolbar.setBackground(background);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(0, 0, 800, 600);
		frame.setLocationRelativeTo(null);

		frame.setVisible(true);

	}

	/**
	 * used when game ends
	 * 
	 * @param gui - GUI: gui reference to acces GameInstances
	 */
	public static void endScreen(GUI gui) {
		JFrame endScreen = new JFrame("Game Over");
		endScreen.setAlwaysOnTop(true);
		JPanel toolbar = new JPanel();

		JButton bttnRestart = new JButton("Restart");
		JButton bttnClose = new JButton("Close");
		JButton bttnStats = new JButton("Stats");
		bttnStats.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				gui.GI.white.stats();
				stats();
			}
		});

		bttnClose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				endScreen.dispose();
			}
		});

		bttnRestart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				gui.start();
				endScreen.dispose();
			}
		});

		JTextArea winner = new JTextArea("The winner is " + gui.GI.winner);
		if (gui.GI.winner == null) {
			endScreen.setTitle("Pat");
			winner.setText("Pat");
		}
		winner.setBackground(background);
		winner.setForeground(Color.white);

		endScreen.setBounds(new Rectangle(400, 400));
		endScreen.setLocationRelativeTo(frame);
		endScreen.setBackground(background);
		endScreen.setResizable(false);

		endScreen.add(winner, BorderLayout.CENTER);
		endScreen.add(toolbar, BorderLayout.NORTH);

		toolbar.add(bttnClose, BorderLayout.AFTER_LAST_LINE);
		toolbar.add(bttnRestart, BorderLayout.AFTER_LAST_LINE);
		toolbar.add(bttnStats, BorderLayout.AFTER_LAST_LINE);

		toolbar.setBackground(background);
		endScreen.setVisible(true);
	}

	/**
	 * used for creating window showing current statistics
	 */
	public static void stats() {
		JFrame endScreen = new JFrame("Stats");
		endScreen.setAlwaysOnTop(true);
		JPanel toolbar = new JPanel();

		JButton bttnClose = new JButton("Close");
		JButton bttnStats = new JButton("Stats");
		bttnStats.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				gui.GI.white.stats();
			}
		});

		bttnClose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				endScreen.dispose();
			}
		});

		Player white = gui.GI.white;
		Player black = gui.GI.black;

		JTextArea stWhite = new JTextArea(white.toString());
		JTextArea stBlack = new JTextArea(black.toString());

		stBlack.setBackground(background);
		stWhite.setBackground(background);
		stBlack.setForeground(Color.white);
		stWhite.setForeground(Color.white);

		endScreen.setBounds(new Rectangle(400, 400));
		endScreen.setLocationRelativeTo(frame);
		endScreen.setBackground(background);
		endScreen.setResizable(false);

		JPanel text = new JPanel();
		text.add(stWhite, BorderLayout.AFTER_LAST_LINE);
		text.add(stBlack, BorderLayout.AFTER_LINE_ENDS);

		text.setBackground(background);
		endScreen.add(text);

		endScreen.add(toolbar, BorderLayout.NORTH);

		toolbar.add(bttnClose, BorderLayout.AFTER_LAST_LINE);

		toolbar.setBackground(background);
		endScreen.setVisible(true);
	}
}
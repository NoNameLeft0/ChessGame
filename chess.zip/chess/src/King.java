import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import java.awt.geom.*;

/**
 * {@summary }
 * King represents a king on a chessboard. King is a concrete class of Piece.
 * King has methods for determining if he is in check, mat and if castling is
 * possible
 * King has additional attributes for easier manipulation
 * 
 * @see Piece
 * 
 * @author Vojtech Brabec
 */
public class King extends Piece {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** a reference to kingside rook for easier manipulation */
	private Rook rookR;
	/** a reference to queenside rook for easier manipulation */
	private Rook rookL;
	/** a reference to GameInstances for easier manipulation */
	private GameInstances GI;
	/** a piece that now threatens this king */
	private Piece checks;
	/**
	 * a boolean indicating if any window that king might trigger is currently being
	 * displayed
	 */
	private boolean windowIsUp = false;

	/**
	 * {@summary Determines if castling is possible}
	 * 
	 * @return true if kingside castling is possible
	 */
	public boolean casleR() {
		if (rookR.movesDone > 0 || this.movesDone > 0 || this.inCheck()) {
			return false;
		}

		if (GI.getPreviousSquare() == null) {
			return false;
		}
		int Iindex = GI.getPreviousSquare().getIindex();
		// is the space between king and rook free?
		if (squares[Iindex][5].hasPiece() || squares[Iindex][6].hasPiece()) {
			return false;
		}

		// will king be in check during castling?
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				Piece p = GI.getPiece(i, j);
				if (p == null || p.getColor().equals(this.getColor())) {
					continue;
				}
				List<Square> movs = p.legalMoves;
				for (int k = 0; k < movs.size(); k++) {
					if (movs.get(k).equals(squares[Iindex][5]) || movs.get(k).equals(squares[Iindex][6])) {
						return false;
					}
				}

			}
		}
		// add a small castle move to legal moves
		legalMoves.add(squares[Iindex][6]);
		return true;
	}

	/**
	 * {@summary Determines if king can perform a queenside castling}
	 * 
	 * @return true if possible
	 */
	public boolean castleL() {
		if (rookL.movesDone > 0 || this.movesDone > 0 || this.inCheck()) {
			return false;
		}

		if (GI.getPreviousSquare() == null) {
			return false;
		}
		int Iindex = GI.getPreviousSquare().getIindex();

		// is the space between king and rook free?
		if (squares[Iindex][3].hasPiece() || squares[Iindex][2].hasPiece() || squares[Iindex][1].hasPiece()) {
			return false;
		}

		// is king in check during castling?
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				Piece p = GI.getPiece(i, j);
				if (p == null || p.getColor().equals(this.getColor())) {
					continue;
				}
				List<Square> movs = p.legalMoves;
				for (int k = 0; k < movs.size(); k++) {
					if (movs.get(k).equals(squares[Iindex][3]) || movs.get(k).equals(squares[Iindex][2])) {
						return false;
					}
				}

			}
		}
		// add queenside castling to moves
		legalMoves.add(squares[Iindex][2]);
		return true;
	}

	/**
	 * 
	 * @return true if king is in check
	 */
	public boolean inCheck() {

		// * INFO check all enemy pieces for possible attacks on king
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				List<Square> checkedPieceMoves = new ArrayList<Square>();
				Piece checkPiece = GI.getPiece(i, j);

				// * INFO skip pieces that can't hurt king
				if (checkPiece == null || checkPiece.equals(this)) {
					continue;
				}
				if (checkPiece.color.equals(this.color)) {
					continue;
				}
				checkedPieceMoves = checkPiece.legalMoves;
				if (checkedPieceMoves == null) {
					continue;
				}
				// * ^

				// * INFO if at least one of the checked pieces can hurt king, return true
				for (int k = 0; k < checkedPieceMoves.size(); k++) {
					if (checkedPieceMoves.get(k).equals(this.getPosition())) {
						checks = checkPiece;
						return true;
					}
				}
			}
		}
		checks = null;
		return false;
	}

	// ! WARNING this method doesn't function properly yet
	/**
	 * ======================
	 * todo FIX
	 * ========================
	 **/
	/**
	 * {@summary Pat isn't implemented yet, doesn't function properly
	 * 
	 * @return true if pat is happening
	 */
	public boolean pat() {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				Piece p = GI.getPiece(i, j);
				if (p == null) {
					continue;
				}
				if (p.equals(this)) {
					for (int k = 0; k < legalMoves.size(); k++) {
						Square prev = getPosition();
						Piece kp = GI.movePiece(this, this.getPosition(), legalMoves.get(k));
						if (!inCheck()) {
							GI.movePiece(this, this.getPosition(), prev);
							GI.reviveThisPiece(kp, legalMoves.get(k));
							return false;
						}
						GI.movePiece(this, this.getPosition(), prev);
						GI.reviveThisPiece(kp, legalMoves.get(k));
					}
				}
				if (p.legalMoves.size() > 0) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * {@summary }checkAllert will create a new JFrame saying that king is in check
	 * and which piece checks him
	 */
	public void checkAllert() {
		if (!windowIsUp) {
			JFrame window = new JFrame(this.toString() + " is in check by: " + checks.toString());
			window.add(checks);
			window.setBounds(new Rectangle(200, 100));
			window.setLocationRelativeTo(Main.frame);
			;
			window.setUndecorated(true);
			window.setAlwaysOnTop(true);
			JButton bttnOk = new JButton("OK");
			JTextArea checkedBy = new JTextArea("CHECK\n" +
					this.toString() + "\nis in check by: " + checks.toString());
			bttnOk.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					windowIsUp = false;
					window.dispose();
				}
			});
			JPanel p = new JPanel();
			p.add(checkedBy, BorderLayout.AFTER_LAST_LINE);
			p.add(bttnOk, BorderLayout.SOUTH);
			p.setBackground(Main.background);
			checkedBy.setBackground(Main.background);
			window.setBackground(Main.background);
			window.add(p);
			window.setVisible(true);
		}
		windowIsUp = true;
	}

	/**
	 * {@summary }inMat determines if this king is in mat.
	 * 
	 * @return true if mat is happening --> game ends
	 */
	public boolean inMat() {
		if (!inCheck()) {
			return false;
		}

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				// * INFO: piece = a friendly living piece
				Piece piece = GI.getPiece(i, j);
				if (piece == null || piece.color != this.color) {
					continue;
				}

				// * INFO: legal moves of piece
				List<Square> pieceLegalMoves = piece.legalMoves();

				// * INFO: piece position
				Square prevSq = piece.getPosition();

				// * INFO: simulate movement of piece for all its possible moves */
				for (int k = 0; k < pieceLegalMoves.size(); k++) {
					// * INFO: piece that will be killed during movement simulation */
					Piece kp = pieceLegalMoves.get(k).getPiece();
					Square kpsqp = null;
					// * ^

					if (kp != null) {
						kpsqp = kp.getPosition();

					}
					// * INFO actual movement simulation
					GI.movePiece(piece, prevSq, pieceLegalMoves.get(k));
					GI.refreshLegalMoves();// * INFO refresh legal moves so we can se if king is saved by this action
					// * INFO if atleas once king is not in check, we can return that this is not
					// mat
					if (!inCheck()) {
						// * INFO reverse simulation
						GI.movePiece(piece, piece.getPosition(), prevSq);
						GI.reviveThisPiece(kp, kpsqp);
						windowIsUp = false;
						return false;
					}
					// * INFO reverse simulation
					GI.movePiece(piece, piece.getPosition(), prevSq);
					GI.reviveThisPiece(kp, kpsqp);
				}
			}
		}
		return true;
	}

	/**
	 * King constructor
	 * 
	 * @param position - {@link Square}: a reference to a Square instance that this
	 *                 King
	 *                 should be placed on
	 * @param color    - {@link Color}: black or white, determines this Kings
	 *                 team/color
	 * @see Piece
	 */
	public King(Square position, Color color) {
		super(position, color);
	}

	/**
	 * =======================
	 * * INFO
	 * This method doesnt check
	 * if king will be in check
	 * on the legal move
	 * ========================
	 **/
	/** @see Piece */
	@Override
	public List<Square> legalMoves() {
		legalMoves = new ArrayList<Square>();
		int Iindex = -1;
		int Jindex = -1;
		boolean found = false;

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (position.equals(squares[i][j])) {
					Iindex = i;
					Jindex = j;
					found = true;
					break;
				}
			}
			if (found) {
				break;
			}
		}
		if (!found) {
			legalMoves.clear();
			return legalMoves;
		}

		Square move;
		for (int i = Iindex - 1, loops = 0; loops < 3 /* && i >= 0 */ && i < 8; i++, loops++) {
			if (i < 0) {
				continue;
			}
			for (int j = Jindex - 1, jloops = 0; jloops < 3 && j < 8; j++, jloops++) {
				if (j < 0) {
					continue;
				}
				move = squares[i][j];
				if (!move.hasPiece()) {
					legalMoves.add(move);
				} else if (!move.getPiece().getColor().equals(this.getColor())) {
					legalMoves.add(move);
				}

			}

		}
		castleL();
		casleR();
		return legalMoves;
	}

	/** @see Piece */
	@Override
	public Shape createShape() {
		int x = position.getPosition().x + padding / 2;
		int y = position.getPosition().y + padding / 2;
		int wid = getWidth() - padding;

		Area shape = new Area();

		Path2D tor = new Path2D.Double();
		tor.moveTo(x + 0.2 * wid, y + wid);
		tor.lineTo(x + 0.38 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.62 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.8 * wid, y + wid);
		tor.closePath();

		double thisw = wid * 0.7;
		shape.add(new Area(new RoundRectangle2D.Double(x + wid * 0.5 - thisw * 0.5, y + 0.9 * wid, thisw, 0.9 * wid,
				0.2 * wid, 0.2 * wid)));
		shape.add(new Area(tor));

		// crownBase
		Path2D crownBase = new Path2D.Double();
		crownBase.moveTo(x + 0.39 * wid, y + 0.45 * wid);
		crownBase.lineTo(x + 0.25 * wid, y + 0.25 * wid);
		crownBase.lineTo(x + 0.75 * wid, y + 0.25 * wid);
		crownBase.lineTo(x + 0.61 * wid, y + 0.45 * wid);
		crownBase.closePath();

		Path2D tr = new Path2D.Double();
		tr.moveTo(x + 0.4 * wid, y + 0.25 * wid);
		tr.lineTo(x + 0.5 * wid, y + 0.15 * wid);
		tr.lineTo(x + 0.6 * wid, y + 0.25 * wid);
		tr.closePath();

		// cross
		thisw = 0.1 * wid;
		double thish = 0.4 * wid;
		shape.add(new Area(
				new Rectangle2D.Double(x + wid * 0.5 - thisw * 0.5, y, thisw, thish)));
		thish = thisw * 0.85;
		thisw = 0.35 * wid;
		shape.add(new Area(new Rectangle2D.Double(x + wid * 0.5 - thisw * 0.5, y +
				0.08 * wid, thisw, thish)));

		shape.add(new Area(tr));
		shape.add(new Area(crownBase));

		return shape;
	}

	/**
	 * ------------------------------------------------------------------------
	 ** SETTERS
	 * ------------------------------------------------------------------------
	 **/

	/**
	 * we set rooks for easier manipulation
	 * 
	 * @param rookR - right side rook
	 * @param rookL - left side rook
	 */
	public void setRooks(Rook rookR, Rook rookL) {
		this.rookR = rookR;
		this.rookL = rookL;
	}

	/**
	 * so that king can see other pieces;
	 * only king can see all pieces, rooks can see only king, any other piece can
	 * see no other piece
	 * 
	 * @param GI - GameInstances: a reference to an instance of GameInstances
	 * 
	 */
	public void setGI(GameInstances GI) {
		this.GI = GI;
	}

	/** @see Piece */
	@Override
	protected void setType() {
		this.type = Type.KING;
	}

}

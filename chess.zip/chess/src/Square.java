import javax.swing.JPanel;

import java.awt.*;

/**
 * {@summary } Square is a representation of a single field on a chessboard
 * A Square has: Piece, position, scale, color, indexes indicating position in
 * 2D array
 * 
 * @see Piece
 * @author Vojtech Brabec
 */
public class Square extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** the length of a side of this square */
	private int scale;
	/** the top left corner of this squre */
	private Point position;
	/** the rectangle that this will be rendered when rendering this square */
	private Rectangle rectangle;
	/** the color of this square, can be any color */
	private Color color;
	/** a piece that currently stands on this square */
	private Piece piece = null;

	/** row position in 2D array */
	private int Iindex = -1;
	/** column position in 2D array */
	private int Jindex = -1;

	// * INFO - also sets rectangle and bounds of this component to this rectangle
	/**
	 * Square constructor
	 * 
	 * @param position - Point: top left corner
	 * @param scale    - int: length of a square side
	 * @param color    - {@link Color}: this color will be rendered
	 * 
	 */
	public Square(Point position, int scale, Color color) {
		this.position = position;
		this.scale = scale;
		this.color = color;
		setRectangle();
		setBounds(rectangle);
	}

	/**
	 * {@summary }hasPoint returns true if the point given as parameter is contained
	 * in this square
	 * 
	 * @param p - Point: a point to be examined
	 * @return true if point is in this square
	 */
	public boolean hasPoint(Point p) {
		if (position.x + rectangle.getWidth() > p.x && position.y + rectangle.getHeight() > p.y && position.x <= p.x
				&& position.y <= p.y) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @return true if this square has a piece
	 */
	public boolean hasPiece() {
		if (piece == null) {
			return false;
		}
		return true;
	}

	/**
	 * {@summary } fills this.rectangle with this.color
	 * 
	 * @param g - Graphics
	 */
	public void paint(Graphics g) {
		g.setColor(color);
		g.fillRect(rectangle.x, rectangle.y, scale, scale);
	}

	/**
	 * {@summary } sets this.rectangle to a new Rectangle()
	 * using this.position as x and y, and this.scale as width and height
	 * 
	 */
	public void setRectangle() {
		rectangle = new Rectangle(position.x, position.y, scale, scale);
		setBounds(rectangle);
	}

	/**
	 * ================================================================================================
	 * SETTERS
	 * ================================================================================================
	 **/

	/**
	 * 
	 * @param scale - int: the scale of this square - a side
	 */
	public void setScale(int scale) {
		this.scale = scale;
	}

	/**
	 * @param position - {@linkplain Point}: the top left corner point of this
	 *                 square
	 */
	public void setPosition(Point position) {
		this.position = position;
	}

	/**
	 * 
	 * @param Iindex - int: row index in 2D array of squares
	 * @param Jindex - int: column index in 2D array of squares
	 */
	public void setIndexes(int Iindex, int Jindex) {
		this.Iindex = Iindex;
		this.Jindex = Jindex;
	}

	/**
	 * 
	 * @param figure - {@linkplain Piece}: a piece that is to supposed to stand on
	 *               this square
	 */
	public void setPiece(Piece figure) {
		this.piece = figure;
	}

	/**
	 * 
	 * @param color - {@linkplain Color}: a color of this square, can be any color
	 */
	public void setColor(Color color) {
		this.color = color;
	}

	/**
	 * ========================================================================
	 ** INFO HEADER
	 * ========================================================================
	 **/
	/**
	 * 
	 * @return piece - {@linkplain Piece}: a Piece that is currently standing on
	 *         this square, if no Piece is present, returns null
	 */
	public Piece getPiece() {
		return piece;
	}

	/**
	 * 
	 * @return position - {@link Point}: the top left corner of this Square
	 */
	public Point getPosition() {
		return position;
	}

	/**
	 * 
	 * @return rectangle - {@linkplain Rectangle}: the rectangle that is rendered
	 */
	public Rectangle getRectangle() {
		return rectangle;
	}

	/**
	 * 
	 * @return color - {@link Color}: the color of this square, with this color the
	 *         square will be filled when rendering
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * 
	 * @return scale - int: the scale of this square
	 */
	public int getScale() {
		return scale;
	}

	/**
	 * 
	 * @return Iindex - int: the row index in 2D array of squares
	 */
	public int getIindex() {
		return Iindex;
	}

	/**
	 * 
	 * @return Jindex - int: the column index in 2D array of squres
	 */
	public int getJindex() {
		return Jindex;
	}

}

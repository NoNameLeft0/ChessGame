import java.awt.Color;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.event.MouseInputAdapter;

/**
 * {@summary }
 * GameInstances holds all the instances that are needed for a chess game. It
 * reacts on a game related input,
 * with help of Piece enforces game rules and implements all game logic.
 * Implicit constructor
 * 
 * 
 * @see Main
 * @see GUI
 * @see Piece
 * @see Type
 * @see Square
 * @see Player
 * @see Move
 * @author Vojtech Brabec
 */
public class GameInstances {
	/**
	 * we need access to this gui for updated scale
	 */
	public GUI gui;

	/** chessboard */
	private Square[][] squares = new Square[8][8];
	/** living pieces, if dead -> on this index null */
	private Piece[][] pieces = new Piece[4][8];

	/** All moves done during gameplay */
	public List<Move> moves = new ArrayList<Move>();
	/** all dead chess pieces */
	public List<KilledPieceInfo> deadPieces = new ArrayList<KilledPieceInfo>();
	/** dead chess pieces that are not pawn */
	public List<KilledPieceInfo> cemetary = new ArrayList<KilledPieceInfo>();
	/** cemetary slots */
	public Square[] cemetarySlots = new Square[14];

	/** player moveing white pieces */
	public Player white;
	/** player moving black pieces */
	public Player black;
	/** will be set if mat appears */
	Player winner = null;

	/** piece that was killed in the last move */
	private Piece killedPiece = null;
	/** piece that is currently selected */
	private Piece selectedPiece;
	/** square we want to move the selected piece to */
	private Square selectedSquare;
	/** square that we moved the selected piece from */
	private Square previousSquare;

	/** the black king - for easier manipulation */
	public King bKing;
	/** the white king - for easier manipulation */
	public King wKing;

	/** queenside black rook - for easier manipulation */
	public Rook bRookL;
	/** kingside black rook - for easier manipulation */
	public Rook bRookR;
	/** queenside white rook - for easier manipulation */
	private Rook wRookR;
	/** kingside white rook - for easier manipulation */
	private Rook wRookL;

	/**
	 * an instance of random for generating random nubers when using
	 * {@code blackCPU()}
	 */
	// private Random random = new Random();

	/** indicates if the game is supposed to end => false -> game is running */
	public boolean gameEnds = false;
	/** indicates if we are playing against pc */
	public boolean blackCPU = false;
	/** points to a move in list of moves we are currently doing */
	private int moveNumber = 0;

	/** cpu player instance */
	CPU cpu;
	/**
	 * operates all game related input
	 * controlls game logic
	 */
	MouseInputAdapter dragAdapter = new MouseInputAdapter() {
		// Square previousSquare;
		/**
		 * {@summary } selects a piece
		 * 
		 * @param e - MouseEvent
		 */
		@Override
		public void mousePressed(MouseEvent e) {
			blackCPU = gui.blackCPU;
			refreshLegalMoves();
			Square start = null;
			selectedPiece = null;
			selectedSquare = null;
			boolean pieceFound = false;
			gui.drawMoves = false;
			Point p = e.getPoint();
			Point pressed = new Point(p.x - gui.x0, p.y - gui.y0);
			/** is there a piece where we clicked? */
			for (int i = 0; i < 4; i++) {
				for (int j = 0; j < 8; j++) {
					if (pieces[i][j] == null) {
						continue;
					}
					if (pieces[i][j].hasPoint(pressed)) {
						selectedPiece = pieces[i][j];
						pieceFound = true;
						break;
					}
				}
				if (pieceFound) {
					start = selectedPiece.getPosition();
					break;
				}
			}
			/** didn't find any piece on this position */
			if (selectedPiece == null) {
				return;
			}

			if (blackCPU && selectedPiece.getColor().equals(Color.black)) {
				return;
			}
			/** position to be restored to in case of an illegal move */
			// previousSquare = selectedPiece.getPosition();

			/** set legal moves */
			// selectedPiece.legalMoves();
			previousSquare = start;
			refreshLegalMoves();

			/**
			 * deetermines which piees can be moved, if we try to move wrong piece, we just
			 * get to pick again
			 */
			if (white.isOnTurn) {
				if (selectedPiece.getColor().equals(Color.white)) {
					gui.drawMoves = true;
				} else {
					selectedPiece = null;
					gui.drawMoves = false;
					return;
				}
			} else {
				if (selectedPiece.getColor().equals(Color.black)) {
					gui.drawMoves = true;
				} else {
					gui.drawMoves = false;
					selectedPiece = null;
					return;
				}
			}
			// hasMoved = selectedPiece.hasMoved;
		};

		/**
		 * {@summary } selects a position to drop the selected piece to
		 * 
		 * @param e - MouseEvent
		 */
		@Override
		public void mouseReleased(MouseEvent e) {
			if (!checkInput(e)) {
				return;
			}

			if (white.isOnTurn) {
				if (selectedPiece.getColor().equals(Color.white)) {
					if (!whiteTurn()) {
						return;
					}
					selectedPiece.movesDone++;
					if (bKing.inMat()) {
						System.out.println("end game");
						System.out.println("white wins");
						winner = white;
						white.endGame();
						gameEnds = true;
						return;
					}
					white.endTurn();
					System.out.println("White turns done: " + white.turnsDone);
					if (blackCPU) {
						blackTurn();
					}
				}
			} else {
				if (selectedPiece.getColor().equals(Color.black)) {

					if (!blackTurn()) {
						return;
					}
					// selectedPiece.hasMoved = true;
					selectedPiece.movesDone++;
					if (wKing.inMat()) {
						System.out.println("end game");
						System.out.println("black wins");
						winner = black;
						white.endGame();
						gameEnds = true;
						return;
					}
					black.endTurn();
					System.out.println("Black turns done: " + black.turnsDone);
				}
			}

		};

	};

	/**
	 * {@summary }
	 * overwrites or adds a move to the list of moves
	 * 
	 * @param move
	 */
	public void replaceOrAddMove(Move move) {
		int size = moves.size();
		// * INFO add a move to list
		if (moveNumber == moves.size()) {
			moves.add(move);
			moveNumber++;
			return;
		}
		// * INFO overwriting a move -> delete all moves that were after it
		if (moveNumber < moves.size()) {
			for (int i = size - 1; i >= moveNumber; i--) {
				moves.remove(i);
			}
			moves.add(moveNumber, move);
			moveNumber = moves.size();
		}

	}

	/**
	 * {@summary } Does castling if player selected to do so, returns true.
	 * Or moves selectedPiece to selectedSquare.
	 * A turn can be finished if a king is not in check -> is king in check?
	 * If turn can end, this turn will be added to the list of moves
	 * 
	 * @return true if white turn really ended
	 */
	private boolean whiteTurn() {
		if (castle(selectedPiece, selectedSquare)) {
			white.endTurn();
			return true;
		}
		killedPiece = movePiece(selectedPiece, previousSquare, selectedSquare);

		;
		refreshLegalMoves();
		if (wKing.inCheck()) {
			wKing.checkAllert();
			reverseLastMove(killedPiece);
			return false;
		}
		replaceOrAddMove(new Move(white, black, selectedPiece, killedPiece, previousSquare, selectedSquare));
		if (selectedPiece.type.equals(Type.PAWN) && selectedSquare.getIindex() == 0) {
			changePiece();
		}
		return true;
	}

	/**
	 * {@summary }
	 * If playing against pc, immideately returns blackCPU method
	 * 
	 * Does castling if player selected to do so, returns true.
	 * Or moves selectedPiece to selectedSquare.
	 * A turn can be finished if a king is not in check -> is king in check?
	 * 
	 * If turn can end, this turn will be added to the list of moves
	 * 
	 * @return true if black turn really ended
	 */
	private boolean blackTurn() {
		// pc player
		if (blackCPU) {
			return cpu.play();
		}
		;
		if (castle(selectedPiece, selectedSquare)) {
			black.endTurn();
			return true;
		}
		// player
		killedPiece = movePiece(selectedPiece, previousSquare, selectedSquare);

		refreshLegalMoves();
		if (bKing.inCheck()) {
			bKing.checkAllert();
			reverseLastMove(killedPiece);
			return false;
		}
		replaceOrAddMove(new Move(white, black, selectedPiece, killedPiece, previousSquare, selectedSquare));

		if (selectedPiece.type.equals(Type.PAWN) && selectedSquare.getIindex() == 7) {
			changePiece();
		}

		return true;

	}

	/**
	 * {@summary } checks if castling is possible and if player chose to do castling
	 * -> performs castling
	 * 
	 * @return true - if castling was performed
	 * @see King
	 */
	public boolean castle(Piece selectedPiece, Square selectedSquare) {
		if (selectedPiece.equals(wKing)) {
			if (wKing.casleR() && selectedSquare.equals(squares[7][6])) {
				movePiece(wKing, previousSquare, selectedSquare);
				replaceOrAddMove(new Move(white, black, wKing, null, previousSquare, selectedSquare, true));
				movePiece(wRookR, wRookR.getPosition(), squares[7][5]);
				wRookR.movesDone++;
				replaceOrAddMove(new Move(white, black, wRookR, null, squares[7][7], wRookR.getPosition(), true));
				return true;
			}
			if (wKing.castleL() && selectedSquare.equals(squares[7][2])) {
				movePiece(wKing, previousSquare, selectedSquare);
				replaceOrAddMove(new Move(white, black, wKing, null, previousSquare, selectedSquare, true));
				movePiece(wRookL, wRookL.getPosition(), squares[7][3]);
				wRookL.movesDone++;
				replaceOrAddMove(new Move(white, black, wRookL, null, squares[7][0], wRookL.getPosition(), true));
				return true;
			}
		}
		if (selectedPiece.equals(bKing)) {
			if (bKing.casleR() && selectedSquare.equals(squares[0][6])) {
				movePiece(bKing, previousSquare, selectedSquare);
				replaceOrAddMove(new Move(white, black, bKing, null, previousSquare, selectedSquare, true));
				movePiece(bRookR, bRookR.getPosition(), squares[0][5]);
				bRookR.movesDone++;
				replaceOrAddMove(new Move(white, black, bRookR, null, squares[0][7], bRookR.getPosition(), true));
				return true;
			}
			if (bKing.castleL() && selectedSquare.equals(squares[0][2])) {
				movePiece(bKing, previousSquare, selectedSquare);
				replaceOrAddMove(new Move(white, black, bKing, null, previousSquare, selectedSquare, true));
				bRookL.movesDone++;
				movePiece(bRookL, bRookL.getPosition(), squares[0][3]);
				replaceOrAddMove(new Move(white, black, bRookL, null, squares[0][0], bRookL.getPosition(), true));
				return true;
			}
		}
		return false;
	}

	/**
	 * {@summary } checks if the mouse input is correct - Is a piece selected?
	 * Is the piece of a correct color?
	 * Is a position to move the piece to selected?
	 * Is the selected position a legal move for this piece?
	 * If all above are true, returns true, else false
	 * 
	 * @param e - MouseEvent: mouse event from {@code mousePressed(MouseEvent e)}
	 * @return boolean - described above
	 * @see Move
	 * @see Piece
	 * @see Square
	 */
	private boolean checkInput(MouseEvent e) {
		gui.drawMoves = false;
		boolean squareFound = false;
		Point p = e.getPoint();
		Point released = new Point(p.x - gui.x0, p.y - gui.y0);
		/** an exception occures without this if... */
		if (selectedPiece == null) {
			gui.repaint();
			return false;
		}

		/** is the piece of a correct color? */
		if ((white.isOnTurn && selectedPiece.getColor().equals(Color.black))
				|| (black.isOnTurn && selectedPiece.getColor().equals(Color.white))) {
			return false;
		}

		/** find a square to put the piece on to */
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (squares[i][j].hasPoint(released)) {
					selectedSquare = squares[i][j];
					squareFound = true;
					break;
				}
			}
			if (squareFound) {
				break;
			}
		}
		/* tried to put piece outside of the chessboard */
		if (!squareFound) {
			selectedSquare = null;
			selectedPiece.setPosition(previousSquare);
			gui.repaint();
			return false;
		}
		/**
		 * if we don't select a new place to put the piece on to, we get to select a
		 * piece again
		 */
		if (selectedPiece.position.equals(selectedSquare)) {
			selectedPiece = null;
			selectedSquare = null;
			gui.repaint();
			return false;
		}
		/** are we making a legal move? */
		boolean moveIsLegal = false;
		for (int i = 0; i < selectedPiece.legalMoves.size(); i++) {
			if (selectedSquare.equals(selectedPiece.legalMoves.get(i))) {
				moveIsLegal = true;
				break;
			}
		}
		/**
		 * move is not legal -> reset dragged piece to it's initial position, deselect
		 * square and piece, try again
		 */
		if (!moveIsLegal) {
			selectedPiece.setPosition(previousSquare);
			selectedSquare = null;
			selectedPiece = null;
			gui.repaint();
			return false;
		}

		gui.repaint();
		return true;
	}

	/**
	 * {@summary }
	 * decrements moveNumber, applies positions from move in list of moves that
	 * moveNumber now points at
	 * 
	 * @see Move
	 */
	private void reverseThisMove() {
		moveNumber--;
		if (moveNumber < 0) {
			moveNumber++;
			return;
		}
		if (moves.size() <= moveNumber) {
			return;
		}
		Move move = moves.get(moveNumber);
		Piece movePiece = move.thisPiece;
		Piece killedPiece = move.killedPiece;
		Square from = move.currentSquare;
		Square to = move.previousSquare;

		movePiece.movesDone--;

		movePiece(movePiece, from, to);

		selectedSquare = to;
		previousSquare = from;

		reviveThisPiece(killedPiece, from);
		if (move.wasCastling && moves.get(moveNumber - 1).wasCastling) {
			reverseThisMove();
		}
		if (white.isOnTurn) {
			white.endTurn();
		} else if (black.isOnTurn) {
			black.endTurn();
		}
		white.turnsDone = move.wTurnsDone;
		black.turnsDone = move.bTurnsDone;
		white.allTimeSpentOnTurn = move.wAllTimeOnTurn;
		black.allTimeSpentOnTurn = move.bAllTimeOnTurn;

	}

	/**
	 * {@summary }
	 * Reverses the effects of the last move made. Not used for reversing turns,
	 * only to reverse movement.
	 * Can be used when simulating a piece's movemen't to reverse the effects
	 * 
	 * @param killedPiece - this piece will be restored;
	 * @see Piece - a piece we want to kill
	 * 
	 */
	public void reverseLastMove(Piece killedPiece) {

		movePiece(selectedPiece, selectedPiece.getPosition(), previousSquare);
		reviveThisPiece(killedPiece, selectedSquare);
		refreshLegalMoves();
	}

	public void reverseThisMove(Move move) {
		Piece killer = move.thisPiece;
		Piece killed = move.killedPiece;
		Square to = move.previousSquare;
		Square from = move.currentSquare;
		movePiece(killer, from, to);
		reviveThisPiece(killed, from);
		refreshLegalMoves();
	}

	/**
	 * {@summary } Currently just changes pawn into queen
	 */
	public void changePiece() {
		for (int i = 0; i < deadPieces.size(); i++) {
			if (deadPieces.get(i).killedPiece.type.equals(Type.QUEEN)
					&& deadPieces.get(i).killedPiece.getColor().equals(selectedPiece.getColor())) {

				killPiece(selectedPiece);
				reviveThisPiece(deadPieces.get(i).killedPiece, selectedSquare);
				return;
			}
		}
	}

	/**
	 * {@summary }
	 * Reverses the move that moveNumber is currently pointing at.
	 * Uses method {@code reverseThisMove()}
	 * 
	 * @see Move
	 */
	public void undo() {
		blackCPU = gui.blackCPU;
		if (moveNumber <= 0) {
			moveNumber = 0;
			return;
		}
		if (blackCPU) {
			reverseThisMove();
			reverseThisMove();
			return;
		}
		reverseThisMove();
	}

	/**
	 * {@summary }
	 * Inverse operation to {@code undo()}
	 * uses method {@code redoThisMove()}
	 * 
	 * @see Move
	 */
	public void redo() {
		blackCPU = gui.blackCPU;
		if (moveNumber >= moves.size()) {
			moveNumber = moves.size();
			return;
		}
		if (blackCPU) {
			redoThisMove();
			redoThisMove();
			return;
		}
		redoThisMove();
	}

	/**
	 * {@summary }
	 * Applies positions from move in list of moves, increments moveNumber
	 * 
	 * @see Move
	 * @see Piece
	 * @see Square
	 */
	private void redoThisMove() {
		if (moveNumber == moves.size()) {
			return;
		}
		Move move = moves.get(moveNumber);
		movePiece(move.thisPiece, move.previousSquare, move.currentSquare);
		moveNumber++;
		move.thisPiece.movesDone++;
		if (move.wasCastling && moves.get(moveNumber - 1).wasCastling) {
			redoThisMove();
			return;
		}

		if (white.isOnTurn) {
			white.endTurn();
			white.allTimeSpentOnTurn = move.wAllTimeOnTurn;
			white.turnsDone = move.wTurnsDone;
		} else if (black.isOnTurn) {
			black.endTurn();
			black.allTimeSpentOnTurn = move.bAllTimeOnTurn;
			black.turnsDone = move.bTurnsDone;
		}
		selectedSquare = move.currentSquare;
		previousSquare = move.previousSquare;
	}

	/**
	 * {@summary}
	 * refreshes legalMoves of all living pieces;
	 * 
	 * @see Piece
	 * @see Square
	 */
	public void refreshLegalMoves() {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				try {
					if (pieces[i][j] != null) {
						pieces[i][j].legalMoves();
					}
				} catch (IndexOutOfBoundsException e) {
					// ignore
					System.out.println("ignored exception " + e.getStackTrace());
					continue;
				}
			}
		}
	}

	/**
	 * {@summary } Moves a piece (move) from a position (from) to a position (to)
	 * 
	 * @param move - {@link Piece}: a piece we are moving
	 * @param from - {@link Square}: a position we are moving the piece from
	 * @param to   - {@link Square}: a position we are moving the piece to
	 * @return killedPiece - {@link Piece}: piece that was killed during movement
	 */
	public Piece movePiece(Piece move, Square from, Square to) {
		Piece killedPiece = killPiece(to.getPiece());
		from.setPiece(null);
		previousSquare = from;
		;
		to.setPiece(move);
		move.setPosition(to);
		return killedPiece;
	}

	/**
	 * {@summary }
	 * restores link between piece and square, returns piece to the list of pieces
	 * 
	 * @param reviveThis - piece to be revived
	 * @param position   - {@link Square} to be revived to
	 * @return Piece - revivedPiece;
	 */
	public Piece reviveThisPiece(Piece reviveThis, Square position) {
		if (reviveThis == null) {
			return null;
		}
		int Iindex = -1;
		int Jindex = -1;
		for (int i = 0; i < deadPieces.size(); i++) {
			if (deadPieces.get(i).killedPiece.equals(reviveThis)) {
				KilledPieceInfo kpi = deadPieces.get(i);
				Iindex = kpi.Iindex;
				Jindex = kpi.Jindex;
				if (reviveThis.getType() != Type.PAWN) {
					cemetary.remove(kpi);
					// for (int j = 0; j < 16; j++) {
					// if (cemetarySlots[j].getPiece().equals(reviveThis)) {
					// cemetarySlots[j].setPiece(null);
					// break;
					// }
					// }
					// for (int k = 0; k < cemetary.size(); k++) {
					// if (cemetary.get(k).killedPiece.equals(reviveThis)) {
					// cemetary.get(k).killedPiece.getPosition().setPiece(killedPiece);
					// cemetary.remove(k);
					// break;
					// }
					// }
				}
				deadPieces.remove(i);
				break;
			}
		}
		if (Iindex < 0 || Iindex > 7 || Jindex < 0 || Jindex > 7) {
			System.out.println("Reviving failed, out of bounds");
			return null;
		}

		reviveThis.getPosition().setPiece(null);
		reviveThis.setPosition(position);
		position.setPiece(reviveThis);

		pieces[Iindex][Jindex] = reviveThis;
		reviveThis.legalMoves();
		return reviveThis;
	}

	/**
	 * {@summary }
	 * Sets killedPieces square to null and its and this squares piece to null
	 * Removes killThis from the pieces
	 * 
	 * 
	 * @param killThis - {@link Piece}: a piece to be removed from the game
	 * @return killThis - {@link Piece}: a reference to the killed piece
	 */
	public Piece killPiece(Piece killThis) {
		int Iindex = -1;
		int Jindex = -1;

		// * INFO if no kill happens, return null
		if (killThis == null) {
			return null;
		}

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				if (pieces[i][j] != null) {
					if (pieces[i][j].equals(killThis)) {
						pieces[i][j] = null;
						Iindex = i;
						Jindex = j;
					}
				}
			}
		}

		killThis.legalMoves.clear();
		;
		KilledPieceInfo kpi = new KilledPieceInfo(killThis, Iindex, Jindex);

		// * INFO is piece pawn? if not we need to add piece to cemetary and
		// * cemetarySpots
		if (killThis.getType() != Type.PAWN) {
			cemetary.add(kpi);

			// * INFO put into cemetary
			Color pieceColor = killThis.getColor();
			if (pieceColor.equals(Color.black)) {
				for (int i = 0; i < cemetarySlots.length / 2; i++) {
					if (cemetarySlots[i].getPiece() == null) {
						cemetarySlots[i].setPiece(killThis);
						killThis.setPosition(cemetarySlots[i]);
						break;
					}
				}
			} else {
				for (int i = cemetarySlots.length / 2; i < cemetarySlots.length; i++) {
					if (cemetarySlots[i].getPiece() == null) {
						cemetarySlots[i].setPiece(killThis);
						killThis.setPosition(cemetarySlots[i]);
						break;
					}
				}
			}
		}

		// * INFO we do this for every piece
		deadPieces.add(kpi);
		killThis.getPosition().setPiece(null);

		return killThis;
	}

	/**
	 * {@summary }
	 * sets up the chess board, all pieces, players.
	 * Initiates game, after setup is finished white is on turn and the game starts
	 * 
	 * @param gui2 - GUI: a GUI instance used for scaling
	 */
	public void setEverything(GUI gui2) {
		this.gui = gui2;
		setSquares();
		setPieces();
		white = new Player("WHITE");
		black = new Player("BLACK");
		black.GI = this;
		white.GI = this;

		white.setopponent(black);
		black.setopponent(white);
		cpu = new CPU(this);
		white.startTurn();

	}

	/**
	 * {@summary }
	 * Prepares the chessboard - fills the {@code squares[8][8]} with instances of
	 * Square
	 * 
	 * @see Square
	 */
	private void setSquares() {
		Color black = new Color(100, 80, 80);
		Color white = new Color(220, 200, 180);
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (i % 2 == 0) {
					if (j % 2 == 0) {
						squares[i][j] = new Square(new Point(j * gui.scale, i * gui.scale), gui.scale, white);
					} else {
						squares[i][j] = new Square(new Point(j * gui.scale, i * gui.scale), gui.scale, black);
					}
				} else {

					if (j % 2 == 0) {
						squares[i][j] = new Square(new Point(j * gui.scale, i * gui.scale), gui.scale, black);
					} else {
						squares[i][j] = new Square(new Point(j * gui.scale, i * gui.scale), gui.scale, white);
					}
				}
				squares[i][j].setIndexes(i, j);
			}
		}

		for (int i = 0; i < cemetarySlots.length; i++) {
			// Color c;
			// if (i >= cemetarySlots.length / 2) {
			// c = white;
			// } else {
			// c = black;
			// }
			cemetarySlots[i] = new Square(new Point(0, 0), gui.scale, Main.background);
		}
	}

	/**
	 * {@summary }
	 * Sets starting positions for default chess game - fills the 2D array
	 * {@code pieces[4][8]} with instances of Piece.
	 * 
	 * @see Piece
	 */
	private void setPieces() {

		// pawns
		for (int i = 1; i < 3; i++) {
			for (int j = 0; j < 8; j++) {
				if (i % 2 == 0) {
					pieces[i][j] = new Pawn(squares[6][j], Color.white);
				} else {
					pieces[i][j] = new Pawn(squares[1][j], Color.black);
				}
			}
		}
		// others pieces
		// whites
		pieces[0][0] = new Rook(squares[0][0], Color.black);
		pieces[0][7] = new Rook(squares[0][7], Color.black);
		pieces[0][6] = new Knight(squares[0][6], Color.black);
		pieces[0][1] = new Knight(squares[0][1], Color.black);
		pieces[0][2] = new Bishop(squares[0][2], Color.black);
		pieces[0][5] = new Bishop(squares[0][5], Color.black);
		pieces[0][4] = new King(squares[0][4], Color.black);
		pieces[0][3] = new Queen(squares[0][3], Color.black);
		// blacks
		pieces[3][7] = new Rook(squares[7][7], Color.white);
		pieces[3][0] = new Rook(squares[7][0], Color.white);
		pieces[3][6] = new Knight(squares[7][6], Color.white);
		pieces[3][1] = new Knight(squares[7][1], Color.white);
		pieces[3][2] = new Bishop(squares[7][2], Color.white);
		pieces[3][5] = new Bishop(squares[7][5], Color.white);
		pieces[3][4] = new King(squares[7][4], Color.white);
		pieces[3][3] = new Queen(squares[7][3], Color.white);

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				pieces[i][j].setSquares(squares);
			}
		}
		bKing = (King) pieces[0][4];
		wKing = (King) pieces[3][4];

		bRookL = (Rook) pieces[0][0];
		bRookR = (Rook) pieces[0][7];
		bRookL.setKing((King) bKing);
		bRookR.setKing((King) bKing);
		wRookR = (Rook) pieces[3][7];
		wRookL = (Rook) pieces[3][0];
		wRookR.setKing((King) wKing);
		wRookL.setKing((King) wKing);

		bKing.setRooks(bRookR, bRookL);
		bKing.setGI(this);

		wKing.setRooks(wRookR, wRookL);
		wKing.setGI(this);

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				pieces[i][j].GI = this;
				pieces[i][j].legalMoves();
			}
		}
	}

	/**
	 * ========================================================================
	 ** SETTERS AND GETTERS **
	 * ========================================================================
	 **/

	/**
	 * @param selectedSquare the selectedSquare to set
	 */
	public void setSelectedSquare(Square selectedSquare) {
		this.selectedSquare = selectedSquare;
	}

	/**
	 * @param previousSquare the previousSquare to set
	 */
	public void setPreviousSquare(Square previousSquare) {
		this.previousSquare = previousSquare;
	}

	/*
	 * -----------------------------------------------------------------------------
	 * -------------------
	 * GETTERS
	 * -----------------------------------------------------------------------------
	 * -------------------
	 */

	/**
	 * 
	 * @return squares - 2D array of squares, basically returning the whole
	 *         chessboard
	 */
	public Square[][] getSquares() {
		return squares;
	}

	/**
	 * @param i - int: row index in 2D array of squares
	 * @param j - int: column index in 2D array of squares
	 * @return Square - a reference to a square in squares[i][j]
	 */
	public Square getSquare(int i, int j) {
		return squares[i][j];
	}

	/**
	 * @return previousSquare - {@link Square}: the previousSquare
	 */
	public Square getPreviousSquare() {
		return previousSquare;
	}

	/**
	 * 
	 * @return pieces - Piece[][]: all pieces, if some are dead - null vallue on
	 *         this index
	 */
	public Piece[][] getPieces() {
		return pieces;
	}

	/**
	 * 
	 * @param i - int: a row index of a piece in pieces[][]
	 * @param j - int: a column index of a piece in pieces[][]
	 * @return - Piece
	 */
	public Piece getPiece(int i, int j) {
		return pieces[i][j];
	}

	/**
	 * 
	 * @return selectedPiece - {@link Piece}: piece that was selected in the last
	 *         move
	 */
	public Piece getSelectedPiece() {
		return selectedPiece;
	}

	/**
	 * @return moveNumber - int: index of a move that is currently being displayed
	 */
	public int getMoveNumber() {
		return moveNumber;
	}

	/**
	 * @return the selectedSquare
	 */
	public Square getSelectedSquare() {
		return selectedSquare;
	}
}

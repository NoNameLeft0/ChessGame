import javax.swing.JPanel;
import java.awt.geom.Area;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * {@summary }
 * Piece represents a piece on a chess board.
 * A piece has a position, it's type, color and possible moves and number of
 * moves performed.
 * 
 * Additionally a piece knows all the possible positions on a chessboard.
 * 
 * @author Vojtech Brabec
 * 
 */
public abstract class Piece extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * moves done by this piece
	 */
	public int movesDone = 0;

	/**
	 * determines if the piece is king, queen, bishop etc.
	 */
	protected Type type;
	/**
	 * determines this pieces position on the chessboard
	 */
	protected Square position;
	/**
	 * is the piece black or white?
	 */
	protected Color color;
	/**
	 * all possible positions on the chessboard
	 */
	protected Square[][] squares;
	/**
	 * a list of all positions that this piece can currently be placed on
	 */
	protected List<Square> legalMoves;

	/**
	 * a padding from left, right, bottm and top so that a piece doesn't take up
	 * all the space on a square
	 */
	public int padding;

	public GameInstances GI;

	/**
	 * 
	 * @param position - {@linkplain Square}: a position on chessboard
	 * @param color    - {@linkplain Color}: black or white;
	 */
	public Piece(Square position, Color color) {
		this.position = position;
		this.color = color;
		position.setPiece(this);
		this.setPosition(position);
		setBounds(this.position.getRectangle());

		padding = (int) (position.getScale() * 0.2);
		setType();
	}

	/**
	 * 
	 * @return legalMoves: List<{@linkplain Square}> - all legal moves that can be
	 *         done by this
	 *         piece
	 */
	public abstract List<Square> legalMoves();

	/**
	 * 
	 * @return shape: Shape - a shape of this piece
	 */
	public abstract Shape createShape();

	/**
	 * {@summary } Creates a clipping area and clpis this piece's visuals
	 * 
	 * @return clip - Area: a clip area that will be subtracted from a Piece area
	 *         when scaling and rendering
	 */
	private Area setClip() {
		int x = position.getPosition().x;
		int y = position.getPosition().y;
		int wid = getWidth();

		Rectangle mid = new Rectangle(x + padding / 2, y + padding / 2, wid - padding, wid - padding);
		Rectangle big = new Rectangle(x - 8 * wid, y - 8 * wid, 16 * wid, 16 * wid);

		Area clip = new Area(big);
		clip.subtract(new Area(mid));

		return clip;
	}

	/**
	 * {@summary Paints this piece}
	 * 
	 * @param g - {@link Graphics}: graphics context for rendering
	 * 
	 */
	public void paint(Graphics g) {
		if (position == null) {
			return;
		}
		Area shape = (Area) createShape();
		if (shape == null) {
			return;
		}
		padding = (int) (position.getScale() * 0.2);
		Area clip = setClip();
		shape.subtract(clip);
		Graphics2D n = (Graphics2D) g;
		BasicStroke bStroke = new BasicStroke(position.getScale() / 45);
		n.setColor(color);
		n.fill(shape);
		n.setStroke(bStroke);
		int r = color.getRed();
		int gr = color.getGreen();
		int b = color.getBlue();
		Color inverse = new Color(255 - r, 255 - gr, 255 - b);
		n.setColor(inverse);
		n.draw(shape);
	}

	/**
	 * 
	 * @return false if can not be saved or isn't in danger, doesn't take into
	 *         consideration sacrificing another piece to save this piece
	 */
	public boolean canBeSaved() {
		List<Piece> pKillers = canBeKilledBy();
		if (pKillers.size() == 0) {
			return false;
		}

		if (pKillers.size() == 1 && pKillers.get(0).canBeKilled()) {
			return true;
		}
		// * INFO for each potential killer try to save this piece, if atleast once is
		// * saved, piece is saved
		Square from = getPosition();
		Square to;
		for (int i = 0; i < pKillers.size(); i++) {
			for (int j = 0; j < legalMoves.size(); j++) {
				to = legalMoves.get(j);
				Piece kp = GI.movePiece(this, from, to);
				if (!canBeKilled()) {
					GI.reverseThisMove(new Move(GI.white, GI.black, this, kp, from, to));
					return true;
				}
				GI.reverseThisMove(new Move(GI.white, GI.black, this, kp, from, to));
			}
		}
		return false;
	}

	/**
	 * 
	 * @param p - {@link Point}: a point to be examined
	 * @return true if the point p is in the square that this piece is standing on
	 */
	public boolean hasPoint(Point p) {
		return this.position.hasPoint(p);
	}

	/**
	 * 
	 * @return killerPieces - List<Piece>: a list of pieces that can kill this piece
	 */
	public List<Piece> canBeKilledBy() {
		Piece[][] pieces = GI.getPieces();
		List<Piece> killerPieces = new ArrayList<>();
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				if (pieces[i][j] == null) {
					continue;
				}
				if (pieces[i][j].equals(this) || this.getColor().equals(pieces[i][j].getColor())) {
					continue;
				}
				List<Square> enemyLegalMoves = pieces[i][j].legalMoves();
				if (enemyLegalMoves == null) {
					continue;
				}
				for (int k = 0; k < enemyLegalMoves.size(); k++) {
					if (this.getPosition().equals(enemyLegalMoves.get(k))) {
						killerPieces.add(pieces[i][j]);
					}
				}
			}
		}
		return killerPieces;
	}

	/**
	 * 
	 * @return - true if at least one of the living pieces can kill this piece
	 */
	public boolean canBeKilled() {
		Piece[][] pieces = GI.getPieces();

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				if (pieces[i][j] == null) {
					continue;
				}
				if (pieces[i][j].equals(this) || this.getColor().equals(pieces[i][j].getColor())) {
					continue;
				}
				List<Square> enemyLegalMoves = pieces[i][j].legalMoves();
				if (enemyLegalMoves == null) {
					continue;
				}
				for (int k = 0; k < enemyLegalMoves.size(); k++) {
					if (this.getPosition().equals(enemyLegalMoves.get(k))) {
						return true;
					}
				}
			}
		}

		return false;
	}

	@Override
	public String toString() {
		String color;
		if (getColor().equals(Color.black)) {
			color = "black";
		} else
			color = "white";
		return color + " " + type;
	}

	/**
	 * ------------------------------------------------------------------------
	 ** SETTERS
	 * ------------------------------------------------------------------------
	 **/

	/**
	 * @param position - {@link Square}: a position on a chessboard that this Piece
	 *                 will
	 *                 stand on
	 */
	public void setPosition(Square position) {
		if (position == null) {
			return;
		}
		this.position = position;
		setBounds(this.position.getRectangle());
	}

	/**
	 * 
	 * @param color - {@link Color}: black or white - determines this Pieces team
	 */
	public void setColor(Color color) {
		this.color = color;
	}

	/**
	 * 
	 * @param squares - {@link Square}[][]: chessboard
	 */
	public void setSquares(Square[][] squares) {
		this.squares = squares;
	}

	/**
	 * {@summary } Sets this pieces Type - king, queen, etc. Each piece sets its own
	 * type
	 */
	protected abstract void setType();

	/**
	 * 
	 * @param padding - int: the padding of this piece from the bounds of it's
	 *                {@linkplain Square}
	 */
	public void setPadding(int padding) {
		this.padding = padding;
	}

	/**
	 * ========================================================================
	 ** INFO HEADER
	 * ========================================================================
	 **/
	/**
	 * 
	 * @return color - {@link Color}:
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * 
	 * @return position - {@link Square}
	 */
	public Square getPosition() {
		return position;
	}

	/**
	 * 
	 * @return type - {@link Type}
	 */
	public Type getType() {
		return type;
	}

	public int getValue() {
		return Type.valueofType(this.getType());
	}

	public int compareTo(Object o) {
		Piece p = (Piece) o;
		return this.getValue() - p.getValue();
	}

}

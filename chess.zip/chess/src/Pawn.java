import java.awt.Color;
import java.awt.Shape;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.List;

/**
 * {@summary }Pawn represents a pawn piece on a chessboard.
 * Pawn is a concrete class of Piece
 * 
 * @see Piece
 * @author Vojtech Brabec
 */
public class Pawn extends Piece {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Pawn constructor
	 * 
	 * @param position - {@link Square}: a position of this pawn on chessboard
	 * @param color    - {@link Color}: black or white - determines the team
	 * @see Piece
	 */
	public Pawn(Square position, Color color) {
		super(position, color);
	}

	/** @see Piece */
	@Override
	public List<Square> legalMoves() {
		legalMoves = new ArrayList<Square>();

		int Iindex = -1;
		int Jindex = -1;
		boolean found = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (position.equals(squares[i][j])) {
					Iindex = i;
					Jindex = j;
					found = true;
					break;
				}
			}
			if (found) {
				break;
			}
		}
		if (!found) {
			legalMoves.clear();
			return legalMoves;
		}
		// whites
		if (getColor().equals(Color.white)) {
			// if (!hasMoved) {
			if (movesDone == 0) {
				for (int i = Iindex - 1, loops = 0; loops < 2; i--, loops++) {
					// if (i == 0) {
					// break;
					// }
					if (squares[i][Jindex].hasPiece()) {
						break;
					}
					legalMoves.add(squares[i][Jindex]);
				}
			}
			if (Iindex > 0) {
				if (!squares[Iindex - 1][Jindex].hasPiece()) {
					legalMoves.add(squares[Iindex - 1][Jindex]);
				}

				if (Jindex < 7) {
					if (squares[Iindex - 1][Jindex + 1].hasPiece()
							&& !squares[Iindex - 1][Jindex + 1].getPiece().getColor().equals(this.getColor())) {
						legalMoves.add(squares[Iindex - 1][Jindex + 1]);
					}
				}
				if (Jindex > 0) {
					if (squares[Iindex - 1][Jindex - 1].hasPiece()
							&& !squares[Iindex - 1][Jindex - 1].getPiece().getColor().equals(this.getColor())) {
						legalMoves.add(squares[Iindex - 1][Jindex - 1]);
					}
				}
			}
		}
		// blacks
		else

		{
			// if (!hasMoved) {
			if (movesDone == 0) {
				for (int i = Iindex + 1, loops = 0; loops < 2; i++, loops++) {
					// if (i == 8) {
					// break;
					// }
					if (squares[i][Jindex].hasPiece()) {
						break;
					}
					legalMoves.add(squares[i][Jindex]);
				}
			}
			if (Iindex < 7) {
				if (!squares[Iindex + 1][Jindex].hasPiece()) {
					legalMoves.add(squares[Iindex + 1][Jindex]);
				}

				if (Jindex < 7) {
					if (squares[Iindex + 1][Jindex + 1].hasPiece()
							&& !squares[Iindex + 1][Jindex + 1].getPiece().getColor().equals(this.getColor())) {
						legalMoves.add(squares[Iindex + 1][Jindex + 1]);
					}
				}
				if (Jindex > 0) {
					if (squares[Iindex + 1][Jindex - 1].hasPiece()
							&& !squares[Iindex + 1][Jindex - 1].getPiece().getColor().equals(this.getColor())) {
						legalMoves.add(squares[Iindex + 1][Jindex - 1]);
					}
				}
			}
		}

		return legalMoves;

	}

	/** @see Piece */
	@Override
	public Shape createShape() {
		int x = position.getPosition().x + padding / 2;
		int y = position.getPosition().y + padding / 2;
		int wid = getWidth() - padding;

		Area shape = new Area();

		Path2D tor = new Path2D.Double();
		tor.moveTo(x + 0.2 * wid, y + wid);
		tor.lineTo(x + 0.38 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.62 * wid, y + 0.5 * wid);
		tor.lineTo(x + 0.8 * wid, y + wid);
		tor.closePath();

		// base
		double thisw = wid * 0.7;
		shape.add(new Area(new RoundRectangle2D.Double(x + wid * 0.5 - thisw * 0.5, y + 0.9 * wid, thisw, 0.9 * wid,
				0.2 * wid, 0.2 * wid)));

		double r = wid * 0.35;
		shape.add(new Area(tor));
		shape.add(new Area(new Ellipse2D.Double(x + wid * 0.5 - r * 0.5, y + 0.45 * wid - r, r, r)));

		return shape;
	}

	/** @see Piece */
	@Override
	protected void setType() {
		this.type = Type.PAWN;
	}
}

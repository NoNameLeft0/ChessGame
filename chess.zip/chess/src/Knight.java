import java.awt.Color;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;
import java.awt.geom.*;

/**
 * {@summary }Knight represents a knight piece on a chessboard.
 * Knitght is a concrete class of Piece
 * 
 * @see Piece
 * @author Vojtech Brabec
 */
public class Knight extends Piece {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Knight constructor
	 * 
	 * @param position
	 * @param color
	 */
	public Knight(Square position, Color color) {
		super(position, color);
	}

	/** @see Piece */
	@Override
	public List<Square> legalMoves() {
		legalMoves = new ArrayList<Square>();
		int Iindex = -1;
		int Jindex = -1;
		boolean found = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (position.equals(squares[i][j])) {
					Iindex = i;
					Jindex = j;
					found = true;
					break;
				}
			}
			if (found) {
				break;
			}
		}
		if (!found) {
			legalMoves.clear();
			return legalMoves;
		}

		if (Iindex < 6) {
			if (Jindex < 7) {
				legalMoves.add(squares[Iindex + 2][Jindex + 1]);
			}
			if (Jindex > 0) {

				legalMoves.add(squares[Iindex + 2][Jindex - 1]);
			}
		}
		if (Iindex < 7) {
			if (Jindex < 6) {
				legalMoves.add(squares[Iindex + 1][Jindex + 2]);
			}
			if (Jindex > 1) {
				legalMoves.add(squares[Iindex + 1][Jindex - 2]);
			}
		}
		if (Iindex > 1) {
			if (Jindex < 7) {
				legalMoves.add(squares[Iindex - 2][Jindex + 1]);
			}
			if (Jindex > 0) {

				legalMoves.add(squares[Iindex - 2][Jindex - 1]);
			}
		}
		if (Iindex > 0) {
			if (Jindex < 6) {

				legalMoves.add(squares[Iindex - 1][Jindex + 2]);
			}
			if (Jindex > 1) {

				legalMoves.add(squares[Iindex - 1][Jindex - 2]);
			}
		}

		Square[] movesToRemove = new Square[8];
		for (int i = 0; i < legalMoves.size(); i++) {
			if (legalMoves.get(i).hasPiece()) {
				if (legalMoves.get(i).getPiece().getColor().equals(this.getColor())) {
					movesToRemove[i] = legalMoves.get(i);
				}
			}
		}
		for (int i = 0; i < 8; i++) {
			if (movesToRemove[i] != null) {
				legalMoves.remove(movesToRemove[i]);
			}
		}
		return legalMoves;
	}

	/** @see Piece */
	@Override
	protected void setType() {
		this.type = Type.KNIGHT;
	}

	/** @see Piece */
	@Override
	public Shape createShape() {
		double x = position.getPosition().x + padding * 0.5;
		double y = position.getPosition().y + padding * 0.5;
		double wid = getWidth() - padding;

		Area shape = new Area();
		// prave ousko
		Path2D rousko = new Path2D.Double();
		rousko.moveTo(x + wid * 0.6, y + wid * 0.2);
		rousko.lineTo(x + wid * 0.6, y);
		rousko.lineTo(x + wid * 0.3, y + wid * 0.2);
		rousko.closePath();
		//

		// leve ousko
		Path2D lousko = new Path2D.Double();
		lousko.moveTo(x + wid * 0.32, y + wid * 0.2);
		lousko.lineTo(x + wid * 0.26, y);
		lousko.lineTo(x + wid * 0.7, y + wid * 0.2);
		lousko.closePath();
		//

		Path2D ousko = new Path2D.Double();
		ousko.moveTo(x + 0.35 * wid, y + 0.1 * wid);
		ousko.lineTo(x + 0.35 * wid, y);
		ousko.lineTo(x + 0.5 * wid, y + 0.1 * wid);
		ousko.closePath();

		// head
		Path2D p = new Path2D.Double();
		p.moveTo(x + 0.75 * wid, y + 0.7 * wid);
		p.lineTo(x + 0.25 * wid, y + 0.7 * wid);

		p.curveTo(x + 0.25 * wid, y + 0.4 * wid, x + 0.6 * wid, y + 0.4 * wid, x + 0.6 * wid, y + 0.4 * wid);
		p.lineTo(x + 0.15 * wid, y + 0.55 * wid);
		p.lineTo(x + 0.05 * wid, y + 0.4 * wid);
		p.lineTo(x + 0.35 * wid, y + 0.1 * wid);
		p.curveTo(x + 1 * wid, y + 0.05 * wid, x + 0.75 * wid, y + 0.7 * wid, x + 0.75 * wid, y + 0.7 * wid);

		p.closePath();

		Path2D tor = new Path2D.Double();
		tor.moveTo(x + 0.2 * wid, y + wid);
		tor.lineTo(x + 0.25 * wid, y + 0.75 * wid);
		tor.lineTo(x + 0.75 * wid, y + 0.75 * wid);
		tor.lineTo(x + 0.8 * wid, y + wid);
		tor.closePath();

		// base
		double thisw = wid * 0.7;
		shape.add(new Area(new RoundRectangle2D.Double(x + wid * 0.5 - thisw * 0.5, y + 0.9 * wid, thisw, 0.9 * wid,
				0.2 * wid, 0.2 * wid)));
		shape.add(new Area(tor));
		shape.add(new Area(p));
		shape.add(new Area(ousko));

		return shape;

	}

}

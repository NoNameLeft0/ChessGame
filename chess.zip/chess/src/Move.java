
/**
 * {@summary } Move holds all relevant information about a move that was
 * performed during gameplay.
 * It is used to undo and redo a move, also for statistics correction.
 * Each time we make a move, we create an instance of Move and save the data
 * about this move here.
 * 
 * @author Vojtech Brabec
 */
public class Move {
	public Square previousSquare = null;
	public Square currentSquare = null;
	public Piece thisPiece = null;
	public Piece killedPiece = null;

	public boolean wasCastling = false;

	public long wThisTimeOnTurn;
	public long bThisTimeOnTurn;

	public long wAllTimeOnTurn;
	public long bAllTimeOnTurn;

	public int wTurnsDone;
	public int bTurnsDone;

	/**
	 * 
	 * {@summary } Move constructor - used for all moves except when castling is
	 * performed
	 * 
	 * @param white       - Player
	 * @param black       - Player
	 * @param thisPiece   - {@link Piece}: piece that moved
	 * @param killedPiece - {@link Piece}: piece that was killed during movement
	 * @param from        - {@link Square}: square from which we moved
	 * @param to          - {@link Square}: square to which we went
	 */
	public Move(Player white, Player black, Piece thisPiece, Piece killedPiece, Square from, Square to) {
		this.thisPiece = thisPiece;
		previousSquare = from;
		currentSquare = to;
		this.killedPiece = killedPiece;
		wThisTimeOnTurn = white.thisTimeOnTurn;
		wAllTimeOnTurn = white.allTimeSpentOnTurn;
		bThisTimeOnTurn = black.thisTimeOnTurn;
		bAllTimeOnTurn = black.allTimeSpentOnTurn;
		wTurnsDone = white.turnsDone;
		bTurnsDone = black.turnsDone;
	}

	/**
	 * {@summary } Move constructor used for a castling situation
	 * 
	 * @param white       - Player
	 * @param black       - Player
	 * @param thisPiece   - {@link Piece}: piece that moved
	 * @param killedPiece - {@link Piece}: piece that was killed during movement
	 * @param from        - {@link Square}: square from which we moved
	 * @param to          - {@link Square}: square to which we went
	 * @param wasCastling - Boolean: was the last move castling?
	 */
	public Move(Player white, Player black, Piece thisPiece, Piece killedPiece, Square from, Square to,
			boolean wasCastling) {
		this.wasCastling = wasCastling;
		this.thisPiece = thisPiece;
		previousSquare = from;
		currentSquare = to;
		this.killedPiece = killedPiece;
		wThisTimeOnTurn = white.thisTimeOnTurn;
		wAllTimeOnTurn = white.allTimeSpentOnTurn;
		bThisTimeOnTurn = black.thisTimeOnTurn;
		bAllTimeOnTurn = black.allTimeSpentOnTurn;
		wTurnsDone = white.turnsDone;
		bTurnsDone = black.turnsDone;
	}

}

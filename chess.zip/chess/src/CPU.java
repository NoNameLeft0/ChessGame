import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class CPU {
	private Random random = new Random();

	private GameInstances GI;
	private Move move;

	Piece pieces[][];

	Player white;
	Player black;

	int killingValue = 0;
	int savingValue = 0;

	// List<Piece> wKillers = new ArrayList<>();
	List<Piece> saveables = new ArrayList<>();

	Piece wKiller;
	Piece saveable;

	Piece killer;
	Piece killable;

	List<Piece> killables = new ArrayList<>();
	List<Piece> killers = new ArrayList<>();

	public CPU(GameInstances GI) {
		this.GI = GI;
		pieces = GI.getPieces();
		black = GI.black;
		white = GI.white;
	}

	public boolean play1() {
		return randomCPU(0);
	}

	public boolean play() {
		killer = null;
		killable = null;
		killables.clear();
		killers.clear();

		attack();

		if (killer != null) {
			turn(killer, killable);
		} else {
			randomCPU(0);
		}
		return true;
	}

	public void attack() {
		findKillables();
		findBestKillers();
		findBestValuePlay();
	}

	public void findKillables() {
		for (int i = 2; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				if (pieces[i][j] == null) {
					continue;
				}

				if (pieces[i][j].canBeKilled()) {
					killables.add(pieces[i][j]);
				}
			}
		}
	}

	public void findBestKillers() {
		// * INFO for each killable there are more potential killers, find the lowest
		// * value one
		for (int i = 0; i < killables.size(); i++) {
			List<Piece> potentialKillers = killables.get(i).canBeKilledBy();
			List<Integer> killerValues = new ArrayList<>();

			// * INFO for each potential killer, load it's value to values
			for (int j = 0; j < potentialKillers.size(); j++) {
				killerValues.add(Type.valueofType(potentialKillers.get(j).getType()));
			}

			// * INFO find the lowest value in killerValues
			if (killerValues.size() == 0) {
				return;
			}

			int result = Collections.min(killerValues);

			for (int j = 0; j < killerValues.size(); j++) {
				if (result == killerValues.get(j)) {
					killers.add(potentialKillers.get(j));
					break;
				}
			}
		}
	}

	public void findBestValuePlay() {
		System.out.println();
		System.out.println("finding best value");
		if (killers.size() == 0 || killables.size() == 0) {
			killer = null;
			killable = null;
			killingValue = -100;
			return;
		}

		List<Integer> results = new ArrayList<>();
		for (int i = 0; i < killables.size(); i++) {
			int killableValue = Type.valueofType(killables.get(i).getType());
			int killerValue = Type.valueofType(killers.get(i).getType());
			results.add(killableValue - killerValue);
		}
		int bestValue = Collections.max(results);
		int get = results.indexOf(bestValue);

		Piece pkiller = killers.get(get);
		Piece pkillable = killables.get(get);

		Square from = pkiller.getPosition();
		Square to = pkillable.getPosition();

		GI.movePiece(pkiller, pkiller.getPosition(), pkillable.getPosition());
		GI.refreshLegalMoves();

		boolean iskKillable = pkiller.canBeKilled();

		if (GI.bKing.inCheck()) {
			killables.remove(pkillable);
			killers.remove(pkiller);
			GI.reverseThisMove(new Move(white, black, pkiller, pkillable, from, to));
			findBestValuePlay();
			return;
		}
		// TODO can be upgraded lots
		if (iskKillable) {
			int pkValue = Type.valueofType(pkiller.getType());
			int pkAbValue = Type.valueofType(pkillable.getType());
			if (pkValue > pkAbValue) {
				killers.remove(pkiller);
				killables.remove(pkillable);
				GI.reverseThisMove(new Move(white, black, pkiller, pkillable, from, to));
				findBestValuePlay();
				return;
			} else {
				killer = pkiller;
				killable = pkillable;
				killingValue = pkAbValue - pkValue;
			}
		} else {
			killer = pkiller;
			killable = pkillable;
			killingValue = Type.valueofType(killable.getType()) - Type.valueofType(killer.getType());
		}

		GI.reverseThisMove(new Move(white, black, pkiller, pkillable, from, to));

	}

	public void turn(Piece moves, Piece dies) {
		// Square to;
		// if(dies == null) {

		// }
		Move move = new Move(white, black, moves, dies, moves.getPosition(), dies.getPosition());

		GI.setSelectedSquare(moves.getPosition());

		GI.replaceOrAddMove(move);
		GI.movePiece(moves, moves.getPosition(), dies.getPosition());

		GI.setSelectedSquare(moves.getPosition());

		moves.movesDone++;

		black.endTurn();
	}

	private boolean randomCPU(int calling) {
		calling++;
		// setup
		Square previousSquare = null;
		Piece selectedPiece = null;
		Square selectedSquare = null;
		;
		// select piece that has at least one legal move randomly
		long timeS = System.currentTimeMillis();
		while (selectedPiece == null || selectedPiece.legalMoves.size() <= 0) {
			selectedPiece = pieces[random.nextInt(0, 2)][random.nextInt(0, 8)];
			if (System.currentTimeMillis() - timeS > 50 || calling > 1000) {
				// white.endGame();
				GI.gameEnds = true;
				return false;
			}
		}
		// prepare for movement
		previousSquare = selectedPiece.getPosition();
		selectedPiece.legalMoves();
		try {
			selectedSquare = selectedPiece.legalMoves.get(random.nextInt(0,
					selectedPiece.legalMoves.size()));
		} catch (IllegalArgumentException exception) {
			System.out.println("illegal argument exception - black cpu - random move " +
					selectedPiece);
			randomCPU(calling);
		}

		if (GI.castle(selectedPiece, selectedSquare)) {
			return true;
		}
		;
		Piece killedPiece = GI.movePiece(selectedPiece, previousSquare,
				selectedSquare);

		// is king in check? recursion
		GI.refreshLegalMoves();
		if (GI.bKing.inCheck()) {
			GI.reverseThisMove(new Move(white, black, selectedPiece, killedPiece,
					previousSquare, selectedSquare));

			return randomCPU(calling);
		}
		System.out.println("did random cpu " + calling);

		GI.setSelectedSquare(selectedSquare);
		GI.setPreviousSquare(previousSquare);

		GI.replaceOrAddMove(new Move(white, black, selectedPiece, killedPiece, previousSquare, selectedSquare));
		black.endTurn();
		return true;
	}

}
